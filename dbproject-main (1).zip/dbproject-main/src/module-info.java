/**
 *
 */
module dbproject {
    requires java.sql;
}
