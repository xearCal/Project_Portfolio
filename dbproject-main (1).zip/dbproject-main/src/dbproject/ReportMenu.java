package dbproject;

public class ReportMenu {

    public static void menu() {
        var inMenu = true;
        while (inMenu) {
            System.out.print("""
                    Member Actions
                    1) Renting Checkouts
                    2) Popular Item
                    3) Popular Manufacturor
                    4) Popular Drone
                    5) Items Checked out
                    6) Equipment by Type of Equipement
                    7) Exit
                    Selection?""" + " ");
            var selection = Main.scanner.nextInt();
            Main.scanner.nextLine(); // consume the newline
            System.out.println();

            switch (selection) {
                case 1 -> rentingCheckouts();
                case 2 -> popularItem();
                case 3 -> popularManufacturor();
                case 4 -> popularDrone();
                case 5 -> itemsCheckedOut();
                case 6 -> equipmentByType();
                case 7 -> inMenu = false;
                default -> System.out.println("Invalid selection");
            }
        }
    }

    private static void rentingCheckouts() {
        // Mirrors the database schema for the rentingCheckoutsRecord table
        // but with Java types.
        record RentingCheckoutsRecord(
                String UserId,
                int itemCount) {
        }
        var memberId = Questionnaire.askInt("Member ID", null, (value) -> value > 0);

        Database.printRecordList(Database.query(RentingCheckoutsRecord.class,
                """
                        SELECT
                            Member.UserID,
                            COUNT(Equipment.SerialNumber) as NumItemsCheckedOut
                        FROM RentalInstance, Member, IncludedIn, Equipment
                        WHERE
                            RentalInstance.UserID = Member.UserID AND
                            IncludedIn.EquipmentManufacturer = Equipment.Manufacturer AND
                            IncludedIn.EquipmentSerialNumber = Equipment.SerialNumber AND
                            IncludedIn.RentalInstanceID = RentalInstance.ID AND Member.UserID = ?
                        """,
                memberId));

    }

    private static void popularItem() {
        // Mirrors the database schema for the rentingCheckoutsRecord table
        // but with Java types.
        record popularItemRecord(
                String EquipmentTypeName,
                float TimeUsed,
                int RentedOut) {
        }

        Database.printRecordList(Database.query(popularItemRecord.class,
                """
                        SELECT
                            EquipmentTypeName,
                            SUM(JULIANDAY(ReturnDate) - JULIANDAY(RentedDate)) AS TimeUsed, COUNT(*) AS RentedOut
                        FROM
                            Equipment AS E
                            JOIN EquipmentType AS ET ON E.Manufacturer = ET.Manufacturer
                            JOIN IncludedIn AS I ON E.SerialNumber = I.EquipmentSerialNumber
                            JOIN RentalInstance AS R ON I.RentalInstanceID = R.ID
                        GROUP BY EquipmentTypeName
                        ORDER BY TimeUsed DESC
                        LIMIT 1;
                            """));
    }

    private static void popularManufacturor() {

        // Mirrors the database schema for the rentingCheckoutsRecord table
        // but with Java types.
        record popularItemRecord(
                String Manufacturer,
                int RentedOut) {
        }
        Database.printRecordList(Database.query(popularItemRecord.class,
                """
                        SELECT
                            E.Manufacturer, COUNT(*) AS RentedOut
                        FROM
                            Equipment AS E
                            JOIN EquipmentType AS ET ON E.Manufacturer = ET.Manufacturer
                            JOIN IncludedIn AS I ON E.SerialNumber = I.EquipmentSerialNumber
                            JOIN RentalInstance AS R ON I.RentalInstanceID = R.ID
                        GROUP BY EquipmentTypeName
                        ORDER BY RentedOut DESC
                        LIMIT 1;
                                """));
    }

    private static void popularDrone() {
        // Mirrors the database schema for the rentingCheckoutsRecord table
        // but with Java types.
        record popularItemRecord(
                String DroneName,
                String SerialNumber,
                float MilesFlown,
                int NumberOfTrips) {
        }
        Database.printRecordList(Database.query(popularItemRecord.class,
                """
                        SELECT
                            DroneName,
                            SerialNumber,
                            SUM(WareHouseDistance) AS MilesFlown,
                            COUNT(*) AS NumberOfTrips
                        FROM Drone AS D
                        JOIN Trip As T ON D.SerialNumber = T.DroneSerialNumber
                        JOIN Member AS M ON T.UserID = M.UserID
                        GROUP BY DroneName, SerialNumber
                        ORDER By MilesFlown DESC
                        LIMIT 1;
                        		"""));
    }

    private static void itemsCheckedOut() {
        // Mirrors the database schema for the rentingCheckoutsRecord table
        // but with Java types.
        record popularItemRecord(
                String UserId,
                int NumItemsCheckedOut) {
        }

        Database.printRecordList(Database.query(popularItemRecord.class,
                """
                        SELECT UserID, MAX(NumItemsCheckedOut)
                        FROM (
                            SELECT Member.UserID, COUNT(Equipment.SerialNumber) as NumItemsCheckedOut
                            FROM RentalInstance, Member, IncludedIn, Equipment
                            WHERE
                                RentalInstance.UserID = Member.UserID AND
                                IncludedIn.EquipmentManufacturer = Equipment.Manufacturer AND
                                IncludedIn.EquipmentSerialNumber = Equipment.SerialNumber AND
                                IncludedIn.RentalInstanceID = RentalInstance.ID
                            GROUP BY Member.UserID
                        );
                        		"""));
    }

    private static void equipmentByType() {
        // Mirrors the database schema for the rentingCheckoutsRecord table
        // but with Java types.
        record popularItemRecord(
                String EquipmentTypeName,
                int EquipmentTypeYear) {
        }

        var manufacturerName = Questionnaire.askString("Manufacturer Name", null, (value) -> value.length() > 0);
        var equipmentYear = Questionnaire.askInt("Year", null, (value) -> value > 0);
        Database.printRecordList(Database.query(popularItemRecord.class,
                """
                                SELECT EquipmentTypeName, EquipmentTypeYear
                                FROM EquipmentType
                                WHERE Manufacturer = ? and EquipmentTypeYear >= ?;
                                ORDER BY EquipmentTypeYear DESC
                        """, manufacturerName, equipmentYear));
    }

}
