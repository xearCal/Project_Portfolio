package dbproject;

import java.time.LocalDate;

public class MemberMenu {
    public static void menu() {
        var inMenu = true;
        while (inMenu) {
            System.out.print("""
                    Member Actions
                    1) List Members
                    2) Add Member
                    3) Remove Member
                    4) Exit
                    Selection?""" + " ");
            var selection = Main.scanner.nextInt();
            Main.scanner.nextLine(); // consume the newline
            System.out.println();

            switch (selection) {
                case 1 -> listMembers();
                case 2 -> placeholder();
                case 3 -> placeholder();
                case 4 -> inMenu = false;
                default -> System.out.println("Invalid selection");
            }
        }
    }

    private static void placeholder() {
        System.out.println("Functionality not yet added.");
    }

    private static void listMembers() {
        record Member(
                String UserID,
                int MemberStatus,
                String FirstName,
                String LastName,
                String MemberAddress,
                String PhoneNumber,
                String Email,
                LocalDate StartDate,
                float WarehouseDistance,
                String CreditCardNumber) {
        }

        Database.printRecordList(Database.query(Member.class, "SELECT * FROM Member"));
    }
}
