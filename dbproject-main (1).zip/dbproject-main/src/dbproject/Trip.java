package dbproject;

import java.time.LocalDate;

public record Trip(int tripId, String currentLocation, LocalDate estArrivalTime, LocalDate departureTime, TripType type,
        int memberId, String warehouseAddress, int droneSerialNumber) {
}
