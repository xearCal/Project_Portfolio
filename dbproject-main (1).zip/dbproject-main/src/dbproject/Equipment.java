package dbproject;

import java.time.LocalDate;

public record Equipment(int serialNumber, Status status, String location, LocalDate warrantyExpiration,
                String manufacturer) {
}
