# dbproject

SP24 CSE 5241 Intro to Database Systems Project

Group Members:

- Jake Browning
- Mark Bundschuh
- Gabe Richner
- Sanyam Shekhawat
- Ryan Snyder
