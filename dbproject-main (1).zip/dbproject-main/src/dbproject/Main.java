package dbproject;

import java.util.Scanner;

public class Main {
	static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		Database.initialize();
		mainMenu();
	}

	private static void mainMenu() {
		var running = true;
		while (running) {
			System.out.print("""
					Main Menu
					1) Drone Actions
					2) Equipment Actions
					3) Member Actions
					4) Trip Actions
					5) Reports
					6) Exit
					Selection?""" + " ");
			var selection = scanner.nextInt();
			scanner.nextLine(); // consume the newline

			System.out.println();

			switch (selection) {
				case 1 -> DroneMenu.menu();
				case 2 -> EquipmentMenu.menu();
				case 3 -> MemberMenu.menu();
				case 4 -> TripMenu.menu();
				case 5 -> ReportMenu.menu();
				case 6 -> running = false;
				default -> System.out.println("Invalid selection");
			}
		}

		scanner.close();
	}

}
