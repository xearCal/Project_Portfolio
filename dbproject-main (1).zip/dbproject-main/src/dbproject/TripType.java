package dbproject;

public enum TripType {
    PICKUP, DELIVERY
}
