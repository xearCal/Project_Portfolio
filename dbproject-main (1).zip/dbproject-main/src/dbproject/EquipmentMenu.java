package dbproject;

public class EquipmentMenu {
    public static void menu() {
        var inMenu = true;
        while (inMenu) {
            System.out.print("""
                    Equipment Actions
                    1) List Equipment
                    2) Search Equipment
                    3) Rent Equipment
                    4) Return Equipment
                    5) Exit
                    Selection?""" + " ");
            var selection = Main.scanner.nextInt();
            Main.scanner.nextLine(); // consume the newline
            System.out.println();

            switch (selection) {
                case 1 -> listEquipment();
                case 2 -> placeholder();
                case 3 -> rentEquipment();
                case 4 -> returnEquipment();
                case 5 -> inMenu = false;
                default -> System.out.println("Invalid selection");
            }
        }
    }

    private static void placeholder() {
        System.out.println("Functionality not yet added.");
    }

    private static void listEquipment() {
        placeholder();
    }

    private static void rentEquipment() {
        System.out.println("Rent Equipment");

        var memberId = Questionnaire.askString("Member ID", null, (value) -> true);

        var equipmentId = Questionnaire.askString("Equipment Serial Number", null, (value) -> value.length() > 0);
        var equipmentManufacturer = Questionnaire.askString("Equipment Manufacturer", null,
                (value) -> value.length() > 0);

        var rentalID = Questionnaire.askString("RentalID", null, (value) -> true);
        var rentedDate = Questionnaire.askDate("Rented Date (yyyy-MM-dd)", null, (value) -> value != null);
        var calculatedFee = Questionnaire.askFloat("Fee", null, (value) -> value > 0);
        var dueDate = Questionnaire.askDate("Due Date", null, (value) -> value != null);

        // THIS SHOULD BE A TRANSACTION
        Database.update("""
                INSERT INTO RentalInstance VALUES (?,?,?,?,?,?)
                """, rentalID, rentedDate, null, calculatedFee, dueDate, memberId);
        Database.update("""
                INSERT INTO IncludedIn VALUES (?,?,?)
                """, equipmentId, equipmentManufacturer, rentalID);
        Database.update("""
                UPDATE Equipment
                SET EquipmentAvailable = 0
                WHERE SerialNumber = ? AND Manufacturer = ?
                """, equipmentId, equipmentManufacturer);
        System.out.println("Renting equipment " + equipmentManufacturer + " " + equipmentId + " to member " + memberId);
    }

    private static void returnEquipment() {
        System.out.println("Return Equipment");

        var equipmentId = Questionnaire.askString("Equipment Serial Number", null, (value) -> value.length() > 0);
        var equipmentManufacturer = Questionnaire.askString("Equipment Manufacturer", null,
                (value) -> value.length() > 0);

        var rentalID = Questionnaire.askString("Rental Instance", null, (value) -> true);
        var returnDate = Questionnaire.askDate("Return Date", null, (value) -> true);

        // THIS SHOULD BE A TRANSACTION (MAYBE)
        Database.update("""
                UPDATE Equipment
                SET EquipmentAvailable = 1
                WHERE SerialNumber = ? AND Manufacturer = ?
                """, equipmentId, equipmentManufacturer);
        Database.update("""
                UPDATE RentalInstance
                SET ReturnDate = ?
                Where ID = ?
                """, returnDate, rentalID);

        System.out.println("Rental " + rentalID + " Was returned on " + returnDate);
    }
}
