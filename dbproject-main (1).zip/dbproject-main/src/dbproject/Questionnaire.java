package dbproject;

import java.time.LocalDate;
import java.util.function.Predicate;

interface Askable<T> {
    T ask(String line);
}

public class Questionnaire {
    private static <T> T ask(String prompt, T fallback, Predicate<T> validator, Askable<T> asker) {
        while (true) {
            System.out.print(prompt);
            if (fallback != null) {
                System.out.print(" [" + fallback + "]");
            }
            System.out.print("? ");

            var input = Main.scanner.nextLine();

            if (input.isBlank()) {
                if (fallback != null) {
                    return fallback;
                }
            }

            T value = asker.ask(input);

            if (value != null && validator.test(value)) {
                return value;
            }

            System.out.println("Invalid input");
        }
    }

    public static int askInt(String prompt, Integer fallback, Predicate<Integer> validator) {
        return ask(prompt, fallback, validator, (input) -> {
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                return null;
            }
        });
    }

    public static float askFloat(String prompt, Float fallback, Predicate<Float> validator) {
        return ask(prompt, fallback, validator, (input) -> {
            try {
                return Float.parseFloat(input);
            } catch (NumberFormatException e) {
                return null;
            }
        });
    }

    public static String askString(String prompt, String fallback, Predicate<String> validator) {
        return ask(prompt, fallback, validator, (input) -> input);
    }

    public static LocalDate askDate(String prompt, LocalDate fallback,
            Predicate<LocalDate> validator) {

        return ask(prompt, fallback, validator, (input) -> {
            try {
                return LocalDate.parse(input);
            } catch (Exception e) {
                return null;
            }
        });
    }
}
