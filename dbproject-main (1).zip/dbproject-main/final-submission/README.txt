csvs.zip - a zipped folder containing csv's which have the source data for the database
AdvanceQueries.txt - List of advanced queries in SQL (queries from Checkpoint 4)
Create.txt - SQL code to create database
ExtraQueries.txt - List of Extra queries in SQL (queries 7-9 from Checkpoint 3)
Populate.txt - SQL code to populate database
ProgramOutputs.pdf - Outputs of the java program as screenshots with labels
ProgramOutputs.txt - Outputs of the java program as a text file (without labels)
Queries.txt - List of Extra queries in SQL (queries 1-6 from Checkpoint 3)
README.txt - This fileViews.txt - SQL for creating the views
eclipse-project.zip - The achive file for the project
eer.png - The ER diagram
final_report.pdf - The final project report. Contains the Database description and the User Manual.
project.db - The database binary file
relational-schema.png - The Relational Schema Diagram

