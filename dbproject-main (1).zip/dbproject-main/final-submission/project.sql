--
-- File generated with SQLiteStudio v3.4.4 on Tue Apr 16 14:03:50 2024
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: CarriedIn
CREATE TABLE IF NOT EXISTS CarriedIn (
    EquipmentSerialNumber TEXT,
    EquipmentManufacturer TEXT,
    TripID                TEXT,
    PRIMARY KEY (
        EquipmentSerialNumber,
        EquipmentManufacturer,
        TripID
    ),
    FOREIGN KEY (
        EquipmentSerialNumber,
        EquipmentManufacturer
    )
    REFERENCES Equipment (SerialNumber,
    Manufacturer),
    FOREIGN KEY (
        TripID
    )
    REFERENCES Trip (ID) 
);

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '85khRYnhXq',
                          'Paint4Fun',
                          '4961959502'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'yAWpq2CKM3',
                          'Plumbing''r''Us',
                          '1490151184'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'uMtji8fx6Z',
                          'GardenTogether',
                          '6099674810'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'ux98VS4hvY',
                          'StandardNetworks',
                          '2935962044'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'oQs5pkjQzH',
                          'Water!',
                          '2715443269'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'VUCkgPY4rv',
                          'ConstructionABC',
                          '5741719163'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'jGnteAPnwa',
                          'ElectricDance',
                          '770153283'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '2kFKqJGbDB',
                          'Water!',
                          '7172825039'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'ipqkXGg8hV',
                          'Paint4Fun',
                          '5890504436'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'aXiKP69wuq',
                          'Plumbing''r''Us',
                          '986573809'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'uEv3Ddgyue',
                          'GardenTogether',
                          '3744605574'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'UzDTLssWye',
                          'StandardNetworks',
                          '3993956931'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'erboahnKtL',
                          'Water!',
                          '3612612255'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '6hffz9WKmC',
                          'ConstructionABC',
                          '967300614'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '97Bu67A4vk',
                          'ElectricDance',
                          '2727186223'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '4XLVhsSFqs',
                          'StandardNetworks',
                          '3290396800'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'DS7hEdmF68',
                          'Paint4Fun',
                          '4880312460'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'wCzgyGhWXd',
                          'Plumbing''r''Us',
                          '3422969098'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'GUz2VmqCKN',
                          'GardenTogether',
                          '8567773628'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'gDE5ocLpUg',
                          'StandardNetworks',
                          '9223852552'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'DZJ9AWHBjR',
                          'Water!',
                          '8273792625'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '8csdriwNfT',
                          'ConstructionABC',
                          '2541466676'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'tYbQPDZMSE',
                          'ElectricDance',
                          '107849348'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '9iBfTdzeQn',
                          'Plumbing''r''Us',
                          '8033754141'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'pwNnihe9hC',
                          'Paint4Fun',
                          '6736247853'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'srrUrCVtfq',
                          'Paint4Fun',
                          '7210031340'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'zF7FM39MjW',
                          'Plumbing''r''Us',
                          '7930053660'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'e8u9RQBtCJ',
                          'GardenTogether',
                          '1414171471'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'NVcqoLk2SG',
                          'StandardNetworks',
                          '2045205967'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'B2xoSmprx5',
                          'Water!',
                          '4413909577'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'Fgvd4pTWEE',
                          'ConstructionABC',
                          '9819652340'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'A3xidbezM4',
                          'ElectricDance',
                          '5462645120'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'afWJkmoFUe',
                          'Paint4Fun',
                          '5027834462'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'mfqceoNrJi',
                          'ElectricDance',
                          '612031772'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'oPzaDryK2W',
                          'ElectricDance',
                          '4357956498'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'maKWnQYmTd',
                          'Paint4Fun',
                          '795751184'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'KTsNP7N4ff',
                          'Plumbing''r''Us',
                          '182151867'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'ki4YYdvXoo',
                          'GardenTogether',
                          '2879818796'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'B5TCcQ3utS',
                          'StandardNetworks',
                          '2718443731'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'RNkYaHnSug',
                          'Water!',
                          '4954852765'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'Bas4c5mGzD',
                          'ElectricDance',
                          '4954852765'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'stAUu6Gxr6',
                          'ConstructionABC',
                          '4954852765'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'K8brJbTSQw',
                          'Paint4Fun',
                          '4954852765'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'AhQbQdjFZg',
                          'Plumbing''r''Us',
                          '182151867'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'd8X5UZsntc',
                          'GardenTogether',
                          '5027834462'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'nqCtRK4cQw',
                          'StandardNetworks',
                          '7210031340'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'jkm3ikSZ3u',
                          'Water!',
                          '3422969098'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'BGjVo3W9pY',
                          'ConstructionABC',
                          '8567773628'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '4B5Db5CZBT',
                          'ElectricDance',
                          '9223852552'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'vKNxiYkgEi',
                          'GardenTogether',
                          '8273792625'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'i8GMM7W8Mz',
                          'ConstructionABC',
                          '2541466676'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'TvxPgJbzeJ',
                          'Plumbing''r''Us',
                          '107849348'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'hQT2R7DQDv',
                          'Paint4Fun',
                          '3422969098'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'e9JMNCvtY8',
                          'Plumbing''r''Us',
                          '8567773628'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '8YxQHraHfV',
                          'GardenTogether',
                          '9223852552'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'bRAGwdQeCm',
                          'StandardNetworks',
                          '8273792625'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'hNbEWMnvuP',
                          'Water!',
                          '2541466676'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'JXNkcJuNbm',
                          'ConstructionABC',
                          '107849348'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '29R7xDTDJ4',
                          'ElectricDance',
                          '2727186223'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '9KJKXVaeEG',
                          'StandardNetworks',
                          '2727186223'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'gj4d2sdk60',
                          'Poopers!',
                          '3744605574'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'BGjVo3W9pY',
                          'ConstructionABC',
                          '7930053660'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '4B5Db5CZBT',
                          'ElectricDance',
                          '1414171471'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'vKNxiYkgEi',
                          'GardenTogether',
                          '2045205967'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'i8GMM7W8Mz',
                          'ConstructionABC',
                          '4413909577'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'TvxPgJbzeJ',
                          'Plumbing''r''Us',
                          '9819652340'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'hQT2R7DQDv',
                          'Paint4Fun',
                          '5462645120'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'e9JMNCvtY8',
                          'Plumbing''r''Us',
                          '5027834462'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '8YxQHraHfV',
                          'GardenTogether',
                          '612031772'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'bRAGwdQeCm',
                          'StandardNetworks',
                          '4357956498'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'hNbEWMnvuP',
                          'Water!',
                          '986573809'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'JXNkcJuNbm',
                          'ConstructionABC',
                          '3744605574'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '29R7xDTDJ4',
                          'ElectricDance',
                          '3993956931'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          '9KJKXVaeEG',
                          'StandardNetworks',
                          '3612612255'
                      );

INSERT INTO CarriedIn (
                          EquipmentSerialNumber,
                          EquipmentManufacturer,
                          TripID
                      )
                      VALUES (
                          'gj4d2sdk60',
                          'Poopers!',
                          '967300614'
                      );


-- Table: Drone
CREATE TABLE IF NOT EXISTS Drone (
    SerialNumber           TEXT     PRIMARY KEY,
    DroneName              TEXT,
    DroneStatus            INT,-- 0 if inactive, 1 if active
    DroneAvailable         INT,-- 0 if unavailable, 1 if available
    DroneLocation          TEXT,
    WarrantyExpirationDate DATETIME,
    ModelNumber            TEXT,
    Manufacturer           TEXT,
    WarehouseAddress       TEXT,
    OrderNumber            TEXT,
    FOREIGN KEY (
        ModelNumber,
        Manufacturer
    )
    REFERENCES DroneSpecs (ModelNumber,
    Manufacturer),
    FOREIGN KEY (
        WarehouseAddress
    )
    REFERENCES Warehouse (WarehouseAddress),
    FOREIGN KEY (
        OrderNumber
    )
    REFERENCES Orders (OrderNumber) 
);

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'M7cPBxV5Eb',
                      'OldFaithful',
                      1,
                      1,
                      '26.7437518,37.3011088',
                      '2027-11-19',
                      '1/7/1900',
                      'ForeverDrone',
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '6593097411'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'PGdChXkjaM',
                      '75Dr',
                      1,
                      0,
                      '108.7986202,28.0896014',
                      '2026-07-23',
                      '1/1/1900',
                      'ValueDrone',
                      '109 Andell Road, Columbus, OH, 43215',
                      '6813138405'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '3t5T9qfEJZ',
                      'AvgDrone',
                      1,
                      1,
                      '33.7584959,59.4907385',
                      '2025-01-20',
                      '1/2/1900',
                      'DroneFac',
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '1946653969'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'EpAKGmpSo2',
                      'iDrone',
                      1,
                      0,
                      '113.543873,22.198745',
                      '2026-10-14',
                      '1/6/1900',
                      'HitDrone',
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '2255927780'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'iFsKGUKtVm',
                      'OldFaithful',
                      1,
                      1,
                      '103.949326,29.20817',
                      '2027-11-19',
                      '1/7/1900',
                      'ForeverDrone',
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '9667408973'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '5BokQYhdTE',
                      'AvgDrone',
                      1,
                      0,
                      '7.7212169,48.6443358',
                      '2025-01-20',
                      '1/2/1900',
                      'DroneFac',
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '6376528813'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'xhywCWdXiG',
                      'iDrone',
                      1,
                      0,
                      '18.5286275,50.2718641',
                      '2026-10-14',
                      '1/6/1900',
                      'HitDrone',
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '7613677354'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'hhznaFc5rX',
                      'iDrone',
                      1,
                      1,
                      '5.8978018,43.4945737',
                      '2026-10-14',
                      '1/6/1900',
                      'HitDrone',
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '7747634498'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '3EYec67gDT',
                      'AvgDrone',
                      1,
                      1,
                      '80.4484871,8.3500276',
                      '2025-01-20',
                      '1/2/1900',
                      'DroneFac',
                      '109 Andell Road, Columbus, OH, 43215',
                      '4460137496'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'jbAEjsXPs3',
                      'AvgDrone',
                      1,
                      1,
                      '-48.6891129,-21.7414439',
                      '2025-01-20',
                      '1/2/1900',
                      'DroneFac',
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '8282474959'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '4Yar9JS2hM',
                      'Zipster95',
                      1,
                      1,
                      '-93.1315648,44.9688472',
                      '2024-08-26',
                      '1/1/1900',
                      'DroneFac',
                      '109 Andell Road, Columbus, OH, 43215',
                      '6593097411'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'Uw5ri3cCTA',
                      'Zipster95',
                      1,
                      0,
                      '106.454213,29.560254',
                      '2024-08-26',
                      '1/1/1900',
                      'DroneFac',
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '5550545667'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'UJm6nr3qBr',
                      'Not2Bad',
                      1,
                      1,
                      '11.0824912,11.7072355',
                      '2024-11-08',
                      '1/4/1900',
                      'ValueDrone',
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '7130080345'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'wYbszcsdoC',
                      'AvgDrone',
                      1,
                      0,
                      '20.5022109,52.4977237',
                      '2025-01-20',
                      '1/2/1900',
                      'DroneFac',
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '7130080345'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'Yy3f34XJAr',
                      'iDrone',
                      1,
                      1,
                      '-97.4508426,32.7311729',
                      '2026-10-14',
                      '1/6/1900',
                      'HitDrone',
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '5840086649'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'HgoaLAheW9',
                      'OldFaithful',
                      1,
                      1,
                      '111.144319,37.518314',
                      '2027-11-19',
                      '1/7/1900',
                      'ForeverDrone',
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '9667408973'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'rpFKbzktsP',
                      '75Dr',
                      1,
                      1,
                      '109.399141,-7.2634241',
                      '2026-07-23',
                      '1/1/1900',
                      'ValueDrone',
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '9604221892'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'FADnceUKZS',
                      'Zipster95',
                      1,
                      1,
                      '119.0110762,-8.4929791',
                      '2024-08-26',
                      '1/1/1900',
                      'DroneFac',
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '6937623208'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'mwkh3mQaCQ',
                      'OldFaithful',
                      1,
                      1,
                      '99.6230001,7.7734885',
                      '2027-11-19',
                      '1/7/1900',
                      'ForeverDrone',
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '7747634498'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'jjNbW8E4AM',
                      'Not2Bad',
                      1,
                      1,
                      '113.38492,22.585397',
                      '2024-11-08',
                      '1/4/1900',
                      'ValueDrone',
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '9604221892'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'MHxK4HNcbC',
                      'OldFaithful',
                      1,
                      0,
                      '16.3904406,50.404284',
                      '2027-11-19',
                      '1/7/1900',
                      'ForeverDrone',
                      '109 Andell Road, Columbus, OH, 43215',
                      '6376528813'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '9FMtD8EMke',
                      'OldFaithful',
                      1,
                      1,
                      '118.099562,4.363324',
                      '2027-11-19',
                      '1/7/1900',
                      'ForeverDrone',
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '6937623208'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'JKcGkMWfoT',
                      'Zipster95',
                      1,
                      0,
                      '17.99097,50.34349',
                      '2024-08-26',
                      '1/1/1900',
                      'DroneFac',
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '9145799369'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'C5x4TEr4jU',
                      '75Dr',
                      1,
                      1,
                      '116.6988851,24.3482735',
                      '2026-07-23',
                      '1/1/1900',
                      'ValueDrone',
                      '109 Andell Road, Columbus, OH, 43215',
                      '2517877483'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '4zduDv2ga3',
                      'Zipster95',
                      1,
                      1,
                      '108.5522531,-6.9375866',
                      '2024-08-26',
                      '1/1/1900',
                      'DroneFac',
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '6813138405'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '8WPTezcKUG',
                      'OldFaithful',
                      1,
                      0,
                      '28.8578584,49.9527773',
                      '2027-11-19',
                      '1/7/1900',
                      'ForeverDrone',
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '6376528813'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'xvQMBcC7wF',
                      'Not2Bad',
                      1,
                      1,
                      '118.089425,24.479833',
                      '2024-11-08',
                      '1/4/1900',
                      'ValueDrone',
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '6593097411'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'AugQEw8AG6',
                      '80Dr',
                      1,
                      0,
                      '125.4067749,41.7467513',
                      '2026-03-27',
                      '1/1/1900',
                      'ValueDrone',
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '1946653969'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'SqDZxbvgSi',
                      'OldFaithful',
                      1,
                      1,
                      '-8.5959634,40.8024339',
                      '2027-11-19',
                      '1/7/1900',
                      'ForeverDrone',
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '1444463608'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'Q2fpSQ7XuQ',
                      'Zipster95',
                      1,
                      1,
                      '25.9358367,48.2920787',
                      '2024-08-26',
                      '1/1/1900',
                      'DroneFac',
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '5550545667'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '8aHr6xzxRj',
                      'iDrone',
                      1,
                      1,
                      '10.4024274,63.4400274',
                      '2026-10-14',
                      '1/6/1900',
                      'HitDrone',
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '5550545667'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'PZYn4M2C6X',
                      '75Dr',
                      1,
                      1,
                      '85.908397,52.020802',
                      '2026-07-23',
                      '1/1/1900',
                      'ValueDrone',
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '2255927780'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'NHcwQM7e3Z',
                      '80Dr',
                      1,
                      0,
                      '36.6901351,47.3292629',
                      '2026-03-27',
                      '1/1/1900',
                      'ValueDrone',
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '8282474959'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'qySBK79viH',
                      'iDrone',
                      1,
                      1,
                      '108.3534306,-7.365205',
                      '2026-10-14',
                      '1/6/1900',
                      'HitDrone',
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '5840086649'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'AsvxDibjDT',
                      '80Dr',
                      1,
                      0,
                      '20.7528378,40.0480719',
                      '2026-03-27',
                      '1/1/1900',
                      'ValueDrone',
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '1444463608'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'pwtPLi4iCk',
                      '80Dr',
                      1,
                      1,
                      '117.15878,33.259035',
                      '2026-03-27',
                      '1/1/190:w0',
                      'ValueDrone',
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '5840086649'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '6n2cxxyCv7',
                      'Not2Bad',
                      1,
                      1,
                      '104.00155,30.652181',
                      '2024-11-08',
                      '1/4/1900',
                      'ValueDrone',
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '9145799369'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'cJS8TJeiLK',
                      'AvgDrone',
                      1,
                      0,
                      '-78.1792434,8.2853585',
                      '2025-01-20',
                      '1/2/1900',
                      'DroneFac',
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '6646292280'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'onpB67DCz7',
                      'iDrone',
                      1,
                      0,
                      '44.018505,49.3268319',
                      '2026-10-14',
                      '1/6/1900',
                      'HitDrone',
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '6646292280'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'J63haYf29H',
                      'AvgDrone',
                      1,
                      0,
                      '-66.8760887,10.4937816',
                      '2025-01-20',
                      '1/2/1900',
                      'DroneFac',
                      '109 Andell Road, Columbus, OH, 43215',
                      '7747634498'
                  );

INSERT INTO Drone (
                      SerialNumber,
                      DroneName,
                      DroneStatus,
                      DroneAvailable,
                      DroneLocation,
                      WarrantyExpirationDate,
                      ModelNumber,
                      Manufacturer,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '1111111111',
                      'epicdropn',
                      1,
                      1,
                      '107.905562,34.955825',
                      '',
                      '4',
                      'manfact',
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '1133402801'
                  );


-- Table: DroneSpecs
CREATE TABLE IF NOT EXISTS DroneSpecs (
    ModelNumber      TEXT,
    Manufacturer     TEXT,
    WeightCapacity   FLOAT,-- lb
    DistanceAutonomy FLOAT,-- mi
    DroneYear        INT,
    MaxSpeed         FLOAT,-- mph
    PRIMARY KEY (
        ModelNumber,
        Manufacturer
    )
);

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '1/7/1900',
                           'ForeverDrone',
                           11.0,
                           24.0,
                           2009,
                           17.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '1/1/1900',
                           'ValueDrone',
                           17.0,
                           77.0,
                           2010,
                           6.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '1/2/1900',
                           'DroneFac',
                           20.0,
                           69.0,
                           2009,
                           15.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '1/6/1900',
                           'HitDrone',
                           7.0,
                           66.0,
                           1993,
                           20.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '1/1/1900',
                           'DroneFac',
                           12.0,
                           81.0,
                           1997,
                           20.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '1/4/1900',
                           'ValueDrone',
                           8.0,
                           93.0,
                           2007,
                           6.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '4',
                           'manfact',
                           4.0,
                           63.0,
                           2009,
                           6.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '1',
                           'MyDrone',
                           11.0,
                           94.0,
                           2011,
                           18.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '2',
                           'MyDrone',
                           19.0,
                           49.0,
                           1983,
                           5.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '3',
                           'MyDrone',
                           4.0,
                           63.0,
                           1997,
                           20.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '4',
                           'MyDrone',
                           12.0,
                           70.0,
                           2000,
                           11.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '5',
                           'MyDrone',
                           16.0,
                           82.0,
                           2007,
                           17.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '6',
                           'MyDrone',
                           7.0,
                           24.0,
                           1973,
                           17.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '7',
                           'MyDrone',
                           7.0,
                           96.0,
                           2009,
                           20.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '8',
                           'MyDrone',
                           1.0,
                           72.0,
                           1985,
                           20.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '9',
                           'MyDrone',
                           2.0,
                           25.0,
                           2001,
                           19.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '10',
                           'MyDrone',
                           16.0,
                           54.0,
                           2012,
                           13.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '11',
                           'MyDrone',
                           2.0,
                           49.0,
                           2002,
                           13.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '12',
                           'MyDrone',
                           5.0,
                           69.0,
                           2013,
                           12.0
                       );

INSERT INTO DroneSpecs (
                           ModelNumber,
                           Manufacturer,
                           WeightCapacity,
                           DistanceAutonomy,
                           DroneYear,
                           MaxSpeed
                       )
                       VALUES (
                           '13',
                           'MyDrone',
                           20.0,
                           61.0,
                           2009,
                           20.0
                       );


-- Table: Equipment
CREATE TABLE IF NOT EXISTS Equipment (
    SerialNumber       TEXT,
    Manufacturer       TEXT,
    EquipmentStatus    INT,-- 0 if inactive, 1 if active
    EquipmentAvailable INT,-- 0 if unavailable, 1 if available
    EquipmentLocation  TEXT,
    WarrantyExpiration DATETIME,
    ModelNumber        TEXT,
    WarehouseAddress   TEXT,
    OrderNumber        TEXT,
    PRIMARY KEY (
        SerialNumber,
        Manufacturer
    ),
    FOREIGN KEY (
        ModelNumber,
        Manufacturer
    )
    REFERENCES EquipmentType (ModelNumber,
    Manufacturer),
    FOREIGN KEY (
        WarehouseAddress
    )
    REFERENCES Warehouse (WarehouseAddress),
    FOREIGN KEY (
        OrderNumber
    )
    REFERENCES Orders (OrderNumber) 
);

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '85khRYnhXq',
                          'Paint4Fun',
                          1,
                          0,
                          '-122.33,47.61',
                          '2022-10-20',
                          '0',
                          '109 Andell Road, Columbus, OH, 43215',
                          '7747634498'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'yAWpq2CKM3',
                          'Plumbing''r''Us',
                          1,
                          1,
                          '113.8437,-8.113',
                          '2024-02-13',
                          '4',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '6593097411'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'uMtji8fx6Z',
                          'GardenTogether',
                          1,
                          1,
                          '-39.6105142,-3.741645',
                          '2024-03-10',
                          '2',
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '7747634498'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'ux98VS4hvY',
                          'StandardNetworks',
                          1,
                          1,
                          '71.486643,30.2102442',
                          '2025-10-02',
                          '6',
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '6593097411'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'oQs5pkjQzH',
                          'Water!',
                          1,
                          0,
                          '-39.0303806,-3.4142906',
                          '2025-02-14',
                          '2',
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '7613677354'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'VUCkgPY4rv',
                          'ConstructionABC',
                          1,
                          0,
                          '26.626104,43.3497076',
                          '2024-03-01',
                          '5',
                          '109 Andell Road, Columbus, OH, 43215',
                          '6646292280'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'jGnteAPnwa',
                          'ElectricDance',
                          1,
                          0,
                          '13.1119454,56.1357417',
                          '2024-08-21',
                          NULL,
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '8282474959'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '2kFKqJGbDB',
                          'Water!',
                          1,
                          0,
                          '-91.148259,15.0270435',
                          NULL,
                          '2',
                          '109 Andell Road, Columbus, OH, 43215',
                          '5840086649'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'ipqkXGg8hV',
                          'Paint4Fun',
                          1,
                          1,
                          '-9.2576801,38.7699889',
                          NULL,
                          '0',
                          '109 Andell Road, Columbus, OH, 43215',
                          '9604221892'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'aXiKP69wuq',
                          'Plumbing''r''Us',
                          1,
                          0,
                          '37.6489954,55.9588361',
                          NULL,
                          '4',
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '5550545667'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'uEv3Ddgyue',
                          'GardenTogether',
                          1,
                          1,
                          '-51.3906526,-22.8664464',
                          NULL,
                          '2',
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '6813138405'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'UzDTLssWye',
                          'StandardNetworks',
                          1,
                          1,
                          '-93.3873133,45.0725651',
                          NULL,
                          '6',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '1444463608'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'erboahnKtL',
                          'Water!',
                          1,
                          1,
                          '-10.6182477,6.446976',
                          NULL,
                          '2',
                          '109 Andell Road, Columbus, OH, 43215',
                          '9667408973'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '6hffz9WKmC',
                          'ConstructionABC',
                          1,
                          0,
                          '35.9396453,32.6434902',
                          NULL,
                          '5',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '9667408973'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '97Bu67A4vk',
                          'ElectricDance',
                          1,
                          1,
                          '51.5097515,32.5538633',
                          NULL,
                          NULL,
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '1133402801'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '4XLVhsSFqs',
                          'StandardNetworks',
                          1,
                          1,
                          '18.0550026,59.3378401',
                          NULL,
                          '6',
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '8282474959'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'DS7hEdmF68',
                          'Paint4Fun',
                          1,
                          0,
                          '27.96979,27.0568',
                          NULL,
                          '0',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '6646292280'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'wCzgyGhWXd',
                          'Plumbing''r''Us',
                          1,
                          0,
                          '120.396768,32.5639',
                          NULL,
                          '4',
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '1444463608'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'GUz2VmqCKN',
                          'GardenTogether',
                          1,
                          1,
                          '117.2911248,2.8426922',
                          NULL,
                          '2',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '6376528813'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'gDE5ocLpUg',
                          'StandardNetworks',
                          1,
                          1,
                          '122.955872,39.704676',
                          NULL,
                          '6',
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '7747634498'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'DZJ9AWHBjR',
                          'Water!',
                          1,
                          0,
                          '17.9879854,59.2689705',
                          NULL,
                          '2',
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '9145799369'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '8csdriwNfT',
                          'ConstructionABC',
                          1,
                          1,
                          '110.942975,27.48051',
                          NULL,
                          '5',
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '5840086649'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'tYbQPDZMSE',
                          'ElectricDance',
                          1,
                          1,
                          '-7.1636637,38.8802788',
                          NULL,
                          NULL,
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '7130080345'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '9iBfTdzeQn',
                          'Plumbing''r''Us',
                          1,
                          1,
                          '-73.54837,18.2618642',
                          NULL,
                          '4',
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '2255927780'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'pwNnihe9hC',
                          'Paint4Fun',
                          1,
                          1,
                          '20.4745018,52.1474235',
                          NULL,
                          '0',
                          '109 Andell Road, Columbus, OH, 43215',
                          '1946653969'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'srrUrCVtfq',
                          'Paint4Fun',
                          1,
                          0,
                          '-8.5055146,30.5395376',
                          NULL,
                          '0',
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '9604221892'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'zF7FM39MjW',
                          'Plumbing''r''Us',
                          1,
                          0,
                          '118.675675,24.874132',
                          NULL,
                          '4',
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '4460137496'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'e8u9RQBtCJ',
                          'GardenTogether',
                          1,
                          1,
                          '-94.6331656,17.9898675',
                          NULL,
                          '2',
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '2255927780'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'NVcqoLk2SG',
                          'StandardNetworks',
                          1,
                          1,
                          '107.281417,-6.2404416',
                          NULL,
                          '6',
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '9145799369'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'B2xoSmprx5',
                          'Water!',
                          1,
                          1,
                          '136.3670325,34.668335',
                          NULL,
                          '2',
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '1444463608'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'Fgvd4pTWEE',
                          'ConstructionABC',
                          1,
                          0,
                          '26.2718021,-32.0078739',
                          NULL,
                          '5',
                          '109 Andell Road, Columbus, OH, 43215',
                          '1133402801'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'A3xidbezM4',
                          'ElectricDance',
                          1,
                          1,
                          '119.3077,-3.4097',
                          NULL,
                          NULL,
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '4460137496'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'afWJkmoFUe',
                          'Paint4Fun',
                          1,
                          1,
                          '121.42185,31.189496',
                          NULL,
                          '0',
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '6813138405'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'mfqceoNrJi',
                          'ElectricDance',
                          1,
                          1,
                          '4.8413855,44.9447526',
                          NULL,
                          NULL,
                          '109 Andell Road, Columbus, OH, 43215',
                          '1946653969'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'oPzaDryK2W',
                          'ElectricDance',
                          1,
                          0,
                          '17.9393289,58.9195438',
                          NULL,
                          NULL,
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '1133402801'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'maKWnQYmTd',
                          'Paint4Fun',
                          1,
                          0,
                          '-97.4252917,20.543509',
                          NULL,
                          '0',
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '2255927780'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'KTsNP7N4ff',
                          'Plumbing''r''Us',
                          1,
                          0,
                          '-51.8628399,-29.3827582',
                          NULL,
                          '4',
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '6937623208'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'ki4YYdvXoo',
                          'GardenTogether',
                          1,
                          1,
                          '30.5234909,48.534282',
                          NULL,
                          '2',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '9604221892'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'B5TCcQ3utS',
                          'StandardNetworks',
                          1,
                          0,
                          '106.7529652,-6.6274275',
                          NULL,
                          '6',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '7613677354'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'RNkYaHnSug',
                          'Water!',
                          1,
                          0,
                          '-65.8412017,-17.5467442',
                          NULL,
                          '2',
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '5550545667'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'Bas4c5mGzD',
                          'ElectricDance',
                          1,
                          1,
                          '124.674591,0.97319',
                          NULL,
                          NULL,
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '6937623208'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'stAUu6Gxr6',
                          'ConstructionABC',
                          1,
                          1,
                          '135.7515062,34.9540542',
                          NULL,
                          '5',
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '8282474959'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'K8brJbTSQw',
                          'Paint4Fun',
                          1,
                          1,
                          '95.4018087,16.2864333',
                          NULL,
                          '0',
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '2517877483'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'AhQbQdjFZg',
                          'Plumbing''r''Us',
                          1,
                          1,
                          '97.7578,2.8583',
                          NULL,
                          '4',
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '9667408973'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'd8X5UZsntc',
                          'GardenTogether',
                          1,
                          1,
                          '-6.2694608,32.5958283',
                          NULL,
                          '2',
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '7130080345'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'nqCtRK4cQw',
                          'StandardNetworks',
                          1,
                          0,
                          '21.7880154,65.2670135',
                          NULL,
                          '6',
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '5550545667'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'jkm3ikSZ3u',
                          'Water!',
                          1,
                          0,
                          '36.5162077,36.1181827',
                          NULL,
                          '2',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '6937623208'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'BGjVo3W9pY',
                          'ConstructionABC',
                          1,
                          1,
                          '-5.7405139,6.9827437',
                          NULL,
                          '5',
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '7613677354'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '4B5Db5CZBT',
                          'ElectricDance',
                          1,
                          0,
                          '29.4562298,47.535711',
                          NULL,
                          NULL,
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '6813138405'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'vKNxiYkgEi',
                          'GardenTogether',
                          1,
                          1,
                          '-72.51581,45.21678',
                          NULL,
                          '2',
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '2517877483'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'i8GMM7W8Mz',
                          'ConstructionABC',
                          1,
                          0,
                          '19.295048,-28.7523',
                          NULL,
                          '5',
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '6593097411'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'TvxPgJbzeJ',
                          'Plumbing''r''Us',
                          1,
                          1,
                          '121.0075554,14.5508865',
                          NULL,
                          '4',
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '6376528813'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'hQT2R7DQDv',
                          'Paint4Fun',
                          1,
                          0,
                          '125.136451,42.901533',
                          NULL,
                          '0',
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '5840086649'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'e9JMNCvtY8',
                          'Plumbing''r''Us',
                          1,
                          1,
                          '36.8430918,53.4405231',
                          NULL,
                          '4',
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '4460137496'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '8YxQHraHfV',
                          'GardenTogether',
                          1,
                          0,
                          '111.8568586,37.2425649',
                          NULL,
                          '2',
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '1946653969'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'bRAGwdQeCm',
                          'StandardNetworks',
                          1,
                          1,
                          '62.0636608,55.2087523',
                          NULL,
                          '6',
                          '109 Andell Road, Columbus, OH, 43215',
                          '2517877483'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'hNbEWMnvuP',
                          'Water!',
                          1,
                          0,
                          '110.0926112,-1.2468663',
                          NULL,
                          '2',
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '7130080345'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'JXNkcJuNbm',
                          'ConstructionABC',
                          1,
                          1,
                          '42.0223291,45.1253665',
                          NULL,
                          '5',
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '2255927780'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '29R7xDTDJ4',
                          'ElectricDance',
                          1,
                          0,
                          '52.7241914,24.1048998',
                          NULL,
                          NULL,
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '4460137496'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          '9KJKXVaeEG',
                          'StandardNetworks',
                          1,
                          1,
                          '110.662033,29.423385',
                          NULL,
                          '6',
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '6376528813'
                      );

INSERT INTO Equipment (
                          SerialNumber,
                          Manufacturer,
                          EquipmentStatus,
                          EquipmentAvailable,
                          EquipmentLocation,
                          WarrantyExpiration,
                          ModelNumber,
                          WarehouseAddress,
                          OrderNumber
                      )
                      VALUES (
                          'gj4d2sdk60',
                          'Poopers!',
                          1,
                          1,
                          '119.79417,4.89111',
                          NULL,
                          '2',
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '6593097411'
                      );


-- Table: EquipmentType
CREATE TABLE IF NOT EXISTS EquipmentType (
    ModelNumber         TEXT,
    Manufacturer        TEXT,
    EquipmentTypeName   TEXT,
    EquipmentTypeYear   INT,
    EquipmentTypeWeight FLOAT,-- lb
    EquipmentTypeType   TEXT,
    EquipmentTypeLength FLOAT,-- in
    EquipmentTypeWidth  FLOAT,-- in
    EquipmentTypeHeight FLOAT,-- in
    PriceToRent         FLOAT,-- cents
    PriceToOrder        FLOAT,-- cents
    PRIMARY KEY (
        ModelNumber,
        Manufacturer
    )
);

INSERT INTO EquipmentType (
                              ModelNumber,
                              Manufacturer,
                              EquipmentTypeName,
                              EquipmentTypeYear,
                              EquipmentTypeWeight,
                              EquipmentTypeType,
                              EquipmentTypeLength,
                              EquipmentTypeWidth,
                              EquipmentTypeHeight,
                              PriceToRent,
                              PriceToOrder
                          )
                          VALUES (
                              '0',
                              'Paint4Fun',
                              'Painting Essentials',
                              2008,
                              20.0,
                              'Painting',
                              25.0,
                              68.0,
                              60.0,
                              3384.0,
                              8810.0
                          );

INSERT INTO EquipmentType (
                              ModelNumber,
                              Manufacturer,
                              EquipmentTypeName,
                              EquipmentTypeYear,
                              EquipmentTypeWeight,
                              EquipmentTypeType,
                              EquipmentTypeLength,
                              EquipmentTypeWidth,
                              EquipmentTypeHeight,
                              PriceToRent,
                              PriceToOrder
                          )
                          VALUES (
                              '4',
                              'Plumbing''r''Us',
                              'Clean Those Pipes Package',
                              2019,
                              25.0,
                              'Plumbing',
                              19.0,
                              87.0,
                              61.0,
                              9054.0,
                              371.0
                          );

INSERT INTO EquipmentType (
                              ModelNumber,
                              Manufacturer,
                              EquipmentTypeName,
                              EquipmentTypeYear,
                              EquipmentTypeWeight,
                              EquipmentTypeType,
                              EquipmentTypeLength,
                              EquipmentTypeWidth,
                              EquipmentTypeHeight,
                              PriceToRent,
                              PriceToOrder
                          )
                          VALUES (
                              '2',
                              'GardenTogether',
                              'Gardening Basics Package',
                              2022,
                              15.0,
                              'Gardening',
                              50.0,
                              41.0,
                              33.0,
                              5535.0,
                              4004.0
                          );

INSERT INTO EquipmentType (
                              ModelNumber,
                              Manufacturer,
                              EquipmentTypeName,
                              EquipmentTypeYear,
                              EquipmentTypeWeight,
                              EquipmentTypeType,
                              EquipmentTypeLength,
                              EquipmentTypeWidth,
                              EquipmentTypeHeight,
                              PriceToRent,
                              PriceToOrder
                          )
                          VALUES (
                              '6',
                              'StandardNetworks',
                              'ComNetwork Standard Package',
                              2020,
                              40.0,
                              'Computer & Network',
                              37.0,
                              86.0,
                              78.0,
                              856.0,
                              9771.0
                          );

INSERT INTO EquipmentType (
                              ModelNumber,
                              Manufacturer,
                              EquipmentTypeName,
                              EquipmentTypeYear,
                              EquipmentTypeWeight,
                              EquipmentTypeType,
                              EquipmentTypeLength,
                              EquipmentTypeWidth,
                              EquipmentTypeHeight,
                              PriceToRent,
                              PriceToOrder
                          )
                          VALUES (
                              '2',
                              'Water!',
                              'Water Irrigation Basics Package',
                              2010,
                              10.0,
                              'Watering',
                              61.0,
                              47.0,
                              98.0,
                              5387.0,
                              1183.0
                          );

INSERT INTO EquipmentType (
                              ModelNumber,
                              Manufacturer,
                              EquipmentTypeName,
                              EquipmentTypeYear,
                              EquipmentTypeWeight,
                              EquipmentTypeType,
                              EquipmentTypeLength,
                              EquipmentTypeWidth,
                              EquipmentTypeHeight,
                              PriceToRent,
                              PriceToOrder
                          )
                          VALUES (
                              '5',
                              'ConstructionABC',
                              'Construction Pack',
                              2023,
                              50.0,
                              'Construction',
                              23.0,
                              79.0,
                              82.0,
                              5540.0,
                              9535.0
                          );

INSERT INTO EquipmentType (
                              ModelNumber,
                              Manufacturer,
                              EquipmentTypeName,
                              EquipmentTypeYear,
                              EquipmentTypeWeight,
                              EquipmentTypeType,
                              EquipmentTypeLength,
                              EquipmentTypeWidth,
                              EquipmentTypeHeight,
                              PriceToRent,
                              PriceToOrder
                          )
                          VALUES (
                              NULL,
                              'ElectricDance',
                              'Basic Electricity Pack',
                              2022,
                              25.0,
                              'Electric',
                              49.0,
                              68.0,
                              80.0,
                              2153.0,
                              9948.0
                          );

INSERT INTO EquipmentType (
                              ModelNumber,
                              Manufacturer,
                              EquipmentTypeName,
                              EquipmentTypeYear,
                              EquipmentTypeWeight,
                              EquipmentTypeType,
                              EquipmentTypeLength,
                              EquipmentTypeWidth,
                              EquipmentTypeHeight,
                              PriceToRent,
                              PriceToOrder
                          )
                          VALUES (
                              '2',
                              'Poopers!',
                              'Pooping Package!',
                              2010,
                              60.0,
                              'Poop',
                              91.0,
                              22.0,
                              89.0,
                              9912.0,
                              9717.0
                          );


-- Table: Fulfill
CREATE TABLE IF NOT EXISTS Fulfill (
    TripID           TEXT,
    RentalInstanceID TEXT,
    PRIMARY KEY (
        TripID,
        RentalInstanceID
    ),
    FOREIGN KEY (
        TripID
    )
    REFERENCES Trip (ID),
    FOREIGN KEY (
        RentalInstanceID
    )
    REFERENCES RentalInstance (ID) 
);

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '4961959502',
                        '1035645807'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '1490151184',
                        '5602634509'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '6099674810',
                        '6722920747'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '2935962044',
                        '8557186517'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '2715443269',
                        '3367340200'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '5741719163',
                        '6480838653'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '770153283',
                        '916646246'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '7172825039',
                        '7162685641'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '5890504436',
                        '6025499071'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '986573809',
                        '664865615'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '3744605574',
                        '4246814024'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '3993956931',
                        '1397810114'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '3612612255',
                        '367145375'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '967300614',
                        '3273421177'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '2727186223',
                        '1247343871'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '3290396800',
                        '7528478857'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '4880312460',
                        '4048634968'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '3422969098',
                        '245644903'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '8567773628',
                        '1244503509'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '9223852552',
                        '182553175'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '8273792625',
                        '1035645807'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '2541466676',
                        '916646246'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '107849348',
                        '7528478857'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '8033754141',
                        '6722920747'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '6736247853',
                        '4246814024'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '7210031340',
                        '3367340200'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '7930053660',
                        '6722920747'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '1414171471',
                        '6480838653'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '2045205967',
                        '4246814024'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '4413909577',
                        '367145375'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '9819652340',
                        '6722920747'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '5462645120',
                        '7162685641'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '5027834462',
                        '1247343871'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '612031772',
                        '7162685641'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '4357956498',
                        '664865615'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '795751184',
                        '4048634968'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '182151867',
                        '3367340200'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '2879818796',
                        '916646246'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '2718443731',
                        '6480838653'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '4954852765',
                        '664865615'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '4880312460',
                        '1035645807'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '4357956498',
                        '1244503509'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '4880312460',
                        '7162685641'
                    );

INSERT INTO Fulfill (
                        TripID,
                        RentalInstanceID
                    )
                    VALUES (
                        '612031772',
                        '7528478857'
                    );


-- Table: IncludedIn
CREATE TABLE IF NOT EXISTS IncludedIn (
    EquipmentSerialNumber TEXT,
    EquipmentManufacturer TEXT,
    RentalInstanceID      TEXT,
    PRIMARY KEY (
        EquipmentSerialNumber,
        EquipmentManufacturer,
        RentalInstanceID
    ),
    FOREIGN KEY (
        EquipmentSerialNumber,
        EquipmentManufacturer
    )
    REFERENCES Equipment (SerialNumber,
    Manufacturer),
    FOREIGN KEY (
        RentalInstanceID
    )
    REFERENCES RentalInstance (ID) 
);

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '85khRYnhXq',
                           'Paint4Fun',
                           '1035645807'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'yAWpq2CKM3',
                           'Plumbing''r''Us',
                           '5602634509'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'uMtji8fx6Z',
                           'GardenTogether',
                           '6722920747'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'ux98VS4hvY',
                           'StandardNetworks',
                           '8557186517'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'oQs5pkjQzH',
                           'Water!',
                           '3367340200'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'VUCkgPY4rv',
                           'ConstructionABC',
                           '6480838653'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'jGnteAPnwa',
                           'ElectricDance',
                           '916646246'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '2kFKqJGbDB',
                           'Water!',
                           '7162685641'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'ipqkXGg8hV',
                           'Paint4Fun',
                           '6025499071'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'aXiKP69wuq',
                           'Plumbing''r''Us',
                           '664865615'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'uEv3Ddgyue',
                           'GardenTogether',
                           '4246814024'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'UzDTLssWye',
                           'StandardNetworks',
                           '1397810114'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'erboahnKtL',
                           'Water!',
                           '367145375'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '6hffz9WKmC',
                           'ConstructionABC',
                           '3273421177'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '97Bu67A4vk',
                           'ElectricDance',
                           '1247343871'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '4XLVhsSFqs',
                           'StandardNetworks',
                           '7528478857'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'DS7hEdmF68',
                           'Paint4Fun',
                           '4048634968'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'wCzgyGhWXd',
                           'Plumbing''r''Us',
                           '245644903'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'GUz2VmqCKN',
                           'GardenTogether',
                           '1244503509'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'gDE5ocLpUg',
                           'StandardNetworks',
                           '182553175'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'DZJ9AWHBjR',
                           'Water!',
                           '1035645807'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '8csdriwNfT',
                           'ConstructionABC',
                           '5602634509'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'tYbQPDZMSE',
                           'ElectricDance',
                           '6722920747'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '9iBfTdzeQn',
                           'Plumbing''r''Us',
                           '8557186517'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'pwNnihe9hC',
                           'Paint4Fun',
                           '3367340200'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'srrUrCVtfq',
                           'Paint4Fun',
                           '6480838653'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'zF7FM39MjW',
                           'Plumbing''r''Us',
                           '916646246'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'e8u9RQBtCJ',
                           'GardenTogether',
                           '7162685641'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'NVcqoLk2SG',
                           'StandardNetworks',
                           '6025499071'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'B2xoSmprx5',
                           'Water!',
                           '664865615'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'Fgvd4pTWEE',
                           'ConstructionABC',
                           '4246814024'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'A3xidbezM4',
                           'ElectricDance',
                           '1397810114'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'afWJkmoFUe',
                           'Paint4Fun',
                           '367145375'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'mfqceoNrJi',
                           'ElectricDance',
                           '3273421177'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'oPzaDryK2W',
                           'ElectricDance',
                           '1247343871'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'maKWnQYmTd',
                           'Paint4Fun',
                           '7528478857'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'KTsNP7N4ff',
                           'Plumbing''r''Us',
                           '4048634968'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'ki4YYdvXoo',
                           'GardenTogether',
                           '245644903'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'B5TCcQ3utS',
                           'StandardNetworks',
                           '1244503509'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'RNkYaHnSug',
                           'Water!',
                           '182553175'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'Bas4c5mGzD',
                           'ElectricDance',
                           '1035645807'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'stAUu6Gxr6',
                           'ConstructionABC',
                           '5602634509'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'K8brJbTSQw',
                           'Paint4Fun',
                           '6722920747'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'AhQbQdjFZg',
                           'Plumbing''r''Us',
                           '8557186517'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'd8X5UZsntc',
                           'GardenTogether',
                           '3367340200'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'nqCtRK4cQw',
                           'StandardNetworks',
                           '6480838653'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'jkm3ikSZ3u',
                           'Water!',
                           '916646246'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'BGjVo3W9pY',
                           'ConstructionABC',
                           '7162685641'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '4B5Db5CZBT',
                           'ElectricDance',
                           '6025499071'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'vKNxiYkgEi',
                           'GardenTogether',
                           '664865615'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'i8GMM7W8Mz',
                           'ConstructionABC',
                           '4246814024'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'TvxPgJbzeJ',
                           'Plumbing''r''Us',
                           '1397810114'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'hQT2R7DQDv',
                           'Paint4Fun',
                           '367145375'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'e9JMNCvtY8',
                           'Plumbing''r''Us',
                           '3273421177'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '8YxQHraHfV',
                           'GardenTogether',
                           '1247343871'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'bRAGwdQeCm',
                           'StandardNetworks',
                           '7528478857'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'hNbEWMnvuP',
                           'Water!',
                           '4048634968'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'JXNkcJuNbm',
                           'ConstructionABC',
                           '245644903'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '29R7xDTDJ4',
                           'ElectricDance',
                           '1244503509'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '9KJKXVaeEG',
                           'StandardNetworks',
                           '182553175'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'gj4d2sdk60',
                           'Poopers!',
                           '1035645807'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '85khRYnhXq',
                           'Paint4Fun',
                           '4246814024'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'yAWpq2CKM3',
                           'Plumbing''r''Us',
                           '1397810114'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'uMtji8fx6Z',
                           'GardenTogether',
                           '367145375'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'ux98VS4hvY',
                           'StandardNetworks',
                           '3273421177'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'oQs5pkjQzH',
                           'Water!',
                           '1247343871'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'VUCkgPY4rv',
                           'ConstructionABC',
                           '7528478857'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'jGnteAPnwa',
                           'ElectricDance',
                           '4048634968'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           '2kFKqJGbDB',
                           'Water!',
                           '245644903'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'ipqkXGg8hV',
                           'Paint4Fun',
                           '1244503509'
                       );

INSERT INTO IncludedIn (
                           EquipmentSerialNumber,
                           EquipmentManufacturer,
                           RentalInstanceID
                       )
                       VALUES (
                           'aXiKP69wuq',
                           'Plumbing''r''Us',
                           '182553175'
                       );


-- Table: Locker
CREATE TABLE IF NOT EXISTS Locker (
    LockerAddress      TEXT  PRIMARY KEY,
    LockerNumber       INT,
    LockerLength       FLOAT,-- in
    LockerWidth        FLOAT,-- in
    LockerHeight       FLOAT,-- in
    LockerCity         TEXT,
    LockerAvailability INT,-- 0 if unavailable, 1 if available
    RentalInstanceID   INT,
    TripID             TEXT,
    UserID             TEXT,
    OrderNumber        TEXT,
    FOREIGN KEY (
        RentalInstanceID
    )
    REFERENCES RentalInstance (ID),
    FOREIGN KEY (
        TripID
    )
    REFERENCES Trip (ID),
    FOREIGN KEY (
        UserID
    )
    REFERENCES Member (UserID),
    FOREIGN KEY (
        OrderNumber
    )
    REFERENCES Orders (OrderNumber) 
);

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '77338 Dunning Place',
                       91,
                       19.0,
                       21.1,
                       91.5,
                       'Froly',
                       0,
                       1035645807,
                       '6736247853',
                       '704836076',
                       '4460137496'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '3622 Burning Wood Plaza',
                       21,
                       36.6,
                       65.0,
                       94.4,
                       'Wirodayan',
                       1,
                       5602634509,
                       '2541466676',
                       '4738212443',
                       '6593097411'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '97199 Petterle Circle',
                       77,
                       37.5,
                       76.5,
                       41.4,
                       'E�zhou',
                       0,
                       6722920747,
                       '1414171471',
                       '7697605201',
                       '2255927780'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '2426 Banding Court',
                       83,
                       80.3,
                       67.8,
                       69.5,
                       'Bagani',
                       1,
                       8557186517,
                       '612031772',
                       '6883879358',
                       '5840086649'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '95232 Kensington Avenue',
                       30,
                       33.8,
                       42.8,
                       36.7,
                       'Nantes',
                       1,
                       3367340200,
                       '967300614',
                       '294301828',
                       '6646292280'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '3 Jackson Park',
                       84,
                       76.3,
                       56.8,
                       57.3,
                       'Smach Mean Chey',
                       0,
                       6480838653,
                       '7210031340',
                       '5118878411',
                       '9145799369'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '8916 Leroy Park',
                       54,
                       71.7,
                       16.3,
                       57.0,
                       'Repentigny',
                       0,
                       916646246,
                       '5462645120',
                       '3140509375',
                       '7747634498'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '185 Morrow Park',
                       42,
                       14.8,
                       76.2,
                       39.5,
                       'Ojiya',
                       1,
                       7162685641,
                       '5890504436',
                       '2075521808',
                       '8282474959'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '9003 Coleman Lane',
                       43,
                       91.4,
                       32.2,
                       39.4,
                       'Paris 18',
                       0,
                       6025499071,
                       '2045205967',
                       '6737671829',
                       '7130080345'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '2314 Carpenter Place',
                       99,
                       98.9,
                       48.1,
                       96.8,
                       'Jalgung',
                       0,
                       664865615,
                       '2718443731',
                       '5560365416',
                       '6376528813'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '405 Dahle Park',
                       61,
                       72.3,
                       49.9,
                       34.6,
                       'Voznesenskoye',
                       1,
                       4246814024,
                       '1490151184',
                       '1838735992',
                       '9604221892'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '33037 Morning Center',
                       69,
                       96.7,
                       46.2,
                       26.3,
                       'Julayjilah',
                       1,
                       1397810114,
                       '4357956498',
                       '7613430332',
                       '6937623208'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '25267 Graceland Trail',
                       41,
                       99.8,
                       59.6,
                       22.1,
                       'Braunschweig',
                       1,
                       367145375,
                       '4880312460',
                       '3093992079',
                       '6813138405'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '6 Veith Point',
                       31,
                       89.1,
                       39.7,
                       99.6,
                       'Trmice',
                       0,
                       3273421177,
                       '2879818796',
                       '3101299349',
                       '1946653969'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '71460 Canary Way',
                       52,
                       78.9,
                       96.9,
                       18.9,
                       'Caen',
                       0,
                       1247343871,
                       '770153283',
                       '1552147452',
                       '9667408973'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '7879 Becker Trail',
                       4,
                       62.6,
                       12.1,
                       34.0,
                       'Liloan',
                       1,
                       7528478857,
                       '107849348',
                       '2374060969',
                       '1444463608'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '6 Butternut Plaza',
                       65,
                       43.5,
                       52.2,
                       77.7,
                       'Zarki',
                       0,
                       4048634968,
                       '4954852765',
                       '7519080234',
                       '5550545667'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '67 Oneill Parkway',
                       86,
                       80.7,
                       86.0,
                       80.4,
                       'Aisai',
                       1,
                       245644903,
                       '3422969098',
                       '6713337155',
                       '1133402801'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '9 Dakota Court',
                       35,
                       68.7,
                       78.1,
                       64.2,
                       'Khodzhi-Gasan',
                       0,
                       1244503509,
                       '795751184',
                       '9912576926',
                       '2517877483'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '1 Heffernan Parkway',
                       52,
                       71.9,
                       89.3,
                       75.6,
                       'Atuntaqui',
                       1,
                       182553175,
                       '3744605574',
                       '399835598',
                       '7613677354'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '781 4th Place',
                       14,
                       87.5,
                       36.2,
                       62.3,
                       'L�xiang',
                       0,
                       6025499071,
                       '2045205967',
                       '6737671829',
                       '1946653969'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '7 Nelson Place',
                       100,
                       97.4,
                       93.8,
                       17.8,
                       'Balangonan',
                       0,
                       6025499071,
                       '2045205967',
                       '6737671829',
                       '2255927780'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '209 Straubel Junction',
                       24,
                       73.8,
                       18.4,
                       27.5,
                       'El Arenal',
                       0,
                       6025499071,
                       '2045205967',
                       '6737671829',
                       '6376528813'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '817 Boyd Hill',
                       86,
                       38.6,
                       25.9,
                       67.1,
                       'Tyarlevo',
                       0,
                       1397810114,
                       '4357956498',
                       '7613430332',
                       '9667408973'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '785 Portage Trail',
                       86,
                       48.8,
                       65.1,
                       94.6,
                       'Sapataria',
                       1,
                       367145375,
                       '4880312460',
                       '3093992079',
                       '4460137496'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '03 Kim Alley',
                       62,
                       85.5,
                       85.0,
                       68.2,
                       'San Felipe',
                       0,
                       3273421177,
                       '2879818796',
                       '3101299349',
                       '7747634498'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '2688 Mallard Lane',
                       34,
                       58.1,
                       13.4,
                       85.3,
                       'Weyburn',
                       1,
                       1247343871,
                       '770153283',
                       '1552147452',
                       '6937623208'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '1 Shopko Point',
                       34,
                       77.7,
                       40.1,
                       40.3,
                       'Mabini',
                       0,
                       7528478857,
                       '107849348',
                       '2374060969',
                       '6646292280'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '381 Buell Park',
                       55,
                       84.9,
                       41.6,
                       89.2,
                       'Shanga',
                       0,
                       8557186517,
                       '612031772',
                       '6883879358',
                       '6937623208'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '222 Larry Hill',
                       62,
                       30.6,
                       42.1,
                       91.1,
                       'Kachia',
                       0,
                       3367340200,
                       '967300614',
                       '294301828',
                       '2517877483'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '41104 Prairie Rose Way',
                       98,
                       30.9,
                       49.1,
                       41.8,
                       'Lapuan',
                       0,
                       6480838653,
                       '7210031340',
                       '5118878411',
                       '2255927780'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '29977 Mayfield Crossing',
                       19,
                       63.4,
                       37.7,
                       60.0,
                       'Kayangel',
                       1,
                       367145375,
                       '4880312460',
                       '3093992079',
                       '1133402801'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '483 Loomis Place',
                       22,
                       65.9,
                       47.4,
                       59.5,
                       'Meijiang',
                       1,
                       3273421177,
                       '2879818796',
                       '3101299349',
                       '8282474959'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '556 John Wall Pass',
                       9,
                       99.4,
                       44.4,
                       31.9,
                       'Shuanghejiedao',
                       0,
                       1247343871,
                       '770153283',
                       '1552147452',
                       '5840086649'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '33639 Bayside Avenue',
                       41,
                       36.0,
                       88.2,
                       28.8,
                       'Claveria',
                       0,
                       7528478857,
                       '107849348',
                       '2374060969',
                       '2255927780'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '25954 Pine View Court',
                       51,
                       48.3,
                       96.1,
                       46.9,
                       'Liutao',
                       1,
                       4048634968,
                       '4954852765',
                       '7519080234',
                       '2255927780'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '159 Vernon Parkway',
                       94,
                       17.6,
                       70.4,
                       19.4,
                       'Hanghuadian',
                       0,
                       6722920747,
                       '1414171471',
                       '7697605201',
                       '9145799369'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '811 Lotheville Place',
                       8,
                       81.5,
                       78.3,
                       63.0,
                       'La Fert�-Bernard',
                       0,
                       8557186517,
                       '612031772',
                       '6883879358',
                       '7747634498'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '3 Service Lane',
                       73,
                       70.7,
                       86.2,
                       90.9,
                       'Dipayal',
                       1,
                       3367340200,
                       '967300614',
                       '294301828',
                       '8282474959'
                   );

INSERT INTO Locker (
                       LockerAddress,
                       LockerNumber,
                       LockerLength,
                       LockerWidth,
                       LockerHeight,
                       LockerCity,
                       LockerAvailability,
                       RentalInstanceID,
                       TripID,
                       UserID,
                       OrderNumber
                   )
                   VALUES (
                       '8 Moland Avenue',
                       88,
                       45.5,
                       28.1,
                       51.5,
                       'Wielichowo',
                       0,
                       6480838653,
                       '7210031340',
                       '5118878411',
                       '7130080345'
                   );


-- Table: Member
CREATE TABLE IF NOT EXISTS Member (
    UserID            TEXT     PRIMARY KEY,
    MemberStatus      INT,-- 0 if inactive, 1 if active
    FirstName         TEXT,
    LastName          TEXT,
    MemberAddress     TEXT,
    PhoneNumber       TEXT,
    Email             TEXT,
    StartDate         DATETIME,
    WarehouseDistance FLOAT,
    CreditCardNumber  INT
);

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '1838735992',
                       0,
                       'Sven',
                       'Doles',
                       '64701 Kropf Crossing',
                       '597-867-5756',
                       'sdoles0@utexas.edu',
                       '2023-08-09',
                       7.0,
                       2343673276
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '704836076',
                       1,
                       'Tulley',
                       'Fullalove',
                       '110 Aberg Terrace',
                       '715-562-2238',
                       'tfullalove1@toplist.cz',
                       '2023-05-17',
                       4.4,
                       1399620037
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '5118878411',
                       1,
                       'Carleen',
                       'Millberg',
                       '8 Crest Line Road',
                       '988-867-8533',
                       'cmillberg2@harvard.edu',
                       '2024-01-19',
                       1.7,
                       516262211
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '2374060969',
                       1,
                       'Kahlil',
                       'Upwood',
                       '2302 Farmco Lane',
                       '233-181-8412',
                       'kupwood3@timesonline.co.uk',
                       '2023-06-04',
                       5.4,
                       7781480252
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '7697605201',
                       1,
                       'Tab',
                       'Raithby',
                       '96743 Southridge Place',
                       '871-979-0817',
                       'traithby4@cdbaby.com',
                       '2023-04-27',
                       4.0,
                       3886404862
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '3093992079',
                       0,
                       'Aristotle',
                       'Snoddin',
                       '52 New Castle Lane',
                       '750-285-2580',
                       'asnoddin5@newyorker.com',
                       '2023-10-04',
                       2.4,
                       3135507882
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '6883879358',
                       1,
                       'Rania',
                       'MacDiarmond',
                       '4 Riverside Way',
                       '397-909-5809',
                       'rmacdiarmond6@canalblog.com',
                       '2023-05-04',
                       5.3,
                       2113863375
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '9912576926',
                       0,
                       'Amelina',
                       'Snewin',
                       '97825 Almo Plaza',
                       '205-522-3599',
                       'asnewin7@baidu.com',
                       '2023-03-09',
                       1.0,
                       1276840691
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '7519080234',
                       0,
                       'Janice',
                       'Treace',
                       '7124 Moose Street',
                       '221-916-0891',
                       'jtreace8@theatlantic.com',
                       '2023-09-29',
                       2.4,
                       3472139757
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '399835598',
                       1,
                       'Mireielle',
                       'Climer',
                       '419 Elmside Hill',
                       '436-870-5647',
                       'mclimer9@umn.edu',
                       '2024-02-02',
                       1.5,
                       8758989277
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '2075521808',
                       1,
                       'Ely',
                       'Denham',
                       '98 Russell Place',
                       '384-922-9482',
                       'edenhama@chron.com',
                       '2023-11-07',
                       4.6,
                       5413545851
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '294301828',
                       1,
                       'Kalli',
                       'Sheddan',
                       '766 Mcbride Point',
                       '359-721-3135',
                       'ksheddanb@surveymonkey.com',
                       '2024-02-20',
                       5.6,
                       4958773029
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '4738212443',
                       0,
                       'Isa',
                       'Bulward',
                       '9 Anderson Point',
                       '883-908-1920',
                       'ibulwardc@discovery.com',
                       '2023-10-28',
                       6.1,
                       51997495
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '1552147452',
                       0,
                       'Jobina',
                       'Dews',
                       '17239 Upham Junction',
                       '151-682-3747',
                       'jdewsd@xing.com',
                       '2024-03-03',
                       9.8,
                       7788532061
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '6737671829',
                       1,
                       'Willie',
                       'Ravilious',
                       '36264 Vera Drive',
                       '783-557-4654',
                       'wraviliouse@loc.gov',
                       '2023-05-07',
                       6.0,
                       7271074228
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '3101299349',
                       0,
                       'Nichole',
                       'Hubbold',
                       '31 Mandrake Court',
                       '561-911-5153',
                       'nhubboldf@mayoclinic.com',
                       '2023-05-03',
                       6.8,
                       1106937082
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '6713337155',
                       1,
                       'Carver',
                       'Beeble',
                       '69691 Lerdahl Parkway',
                       '781-872-0738',
                       'cbeebleg@liveinternet.ru',
                       '2023-07-21',
                       6.6,
                       5788453380
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '7613430332',
                       1,
                       'Mirelle',
                       'Mertgen',
                       '1246 Helena Drive',
                       '784-409-7288',
                       'mmertgenh@squarespace.com',
                       '2024-02-23',
                       4.8,
                       498041050
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '3140509375',
                       1,
                       'Rodie',
                       'Louiset',
                       '19486 Butternut Circle',
                       '292-889-5258',
                       'rlouiseti@sina.com.cn',
                       '2023-11-08',
                       8.6,
                       7308288501
                   );

INSERT INTO Member (
                       UserID,
                       MemberStatus,
                       FirstName,
                       LastName,
                       MemberAddress,
                       PhoneNumber,
                       Email,
                       StartDate,
                       WarehouseDistance,
                       CreditCardNumber
                   )
                   VALUES (
                       '5560365416',
                       0,
                       'Jillane',
                       'Mustarde',
                       '9391 Randy Center',
                       '422-248-8179',
                       'jmustardej@twitpic.com',
                       '2023-04-12',
                       8.2,
                       1648452701
                   );


-- Table: Orders
CREATE TABLE IF NOT EXISTS Orders (
    OrderNumber            TEXT     PRIMARY KEY,
    OrderType              INT,-- 0 for drone, 1 for truck, 2 for locker, 3 for equipment
    Quantity               INT,
    OrderValue             INT,-- cost in cents
    EstimatedDateOfArrival DATETIME,
    ActualDateOfArrival    DATETIME,
    WarehouseAddress       TEXT,
    FOREIGN KEY (
        WarehouseAddress
    )
    REFERENCES Warehouse (WarehouseAddress) 
);

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '4460137496',
                       1,
                       34,
                       51115,
                       '2023-05-24',
                       '2023-07-01',
                       '2639 Quilly Lane, Columbus, OH, 43215'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '6593097411',
                       2,
                       16,
                       92837,
                       '2023-09-01',
                       '2023-04-29',
                       '4249 Pringle Drive, Dayton, OH, 45469'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '2255927780',
                       3,
                       38,
                       87405,
                       '2023-06-23',
                       '2023-08-14',
                       '4249 Pringle Drive, Dayton, OH, 45469'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '5840086649',
                       3,
                       7,
                       61843,
                       '2023-06-04',
                       '2023-04-06',
                       '3041 Hiddenview Drive, Cleveland, OH, 44114'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '6646292280',
                       2,
                       26,
                       91539,
                       '2023-08-20',
                       '2023-10-19',
                       '2944 Sunny Glen Lane, Cleveland, OH, 44103'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '9145799369',
                       3,
                       22,
                       5103,
                       '2024-02-27',
                       '2023-03-18',
                       '2639 Quilly Lane, Columbus, OH, 43215'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '7747634498',
                       3,
                       12,
                       74478,
                       '2024-01-23',
                       '2023-03-25',
                       '1516 Ingram Street, Dayton, OH, 45408'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '8282474959',
                       2,
                       14,
                       40273,
                       '2024-01-04',
                       '2023-08-05',
                       '109 Andell Road, Columbus, OH, 43215'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '7130080345',
                       3,
                       13,
                       74840,
                       '2023-11-24',
                       '2023-11-26',
                       '2639 Quilly Lane, Columbus, OH, 43215'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '6376528813',
                       0,
                       31,
                       50198,
                       '2023-11-01',
                       '2023-06-19',
                       '109 Andell Road, Columbus, OH, 43215'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '9604221892',
                       3,
                       10,
                       55446,
                       '2023-05-10',
                       '2023-07-16',
                       '2944 Sunny Glen Lane, Cleveland, OH, 44103'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '6937623208',
                       0,
                       33,
                       29713,
                       '2023-08-25',
                       '2023-04-15',
                       '1516 Ingram Street, Dayton, OH, 45408'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '6813138405',
                       3,
                       24,
                       37440,
                       '2023-11-01',
                       '2023-05-12',
                       '2573 James Martin Circle, Columbus, OH, 43085'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '1946653969',
                       1,
                       28,
                       87507,
                       '2023-06-15',
                       '2023-08-05',
                       '3041 Hiddenview Drive, Cleveland, OH, 44114'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '9667408973',
                       3,
                       4,
                       34923,
                       '2023-03-30',
                       '2023-07-06',
                       '1516 Ingram Street, Dayton, OH, 45408'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '1444463608',
                       2,
                       24,
                       31530,
                       '2024-02-16',
                       '2023-11-25',
                       '109 Andell Road, Columbus, OH, 43215'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '5550545667',
                       0,
                       38,
                       14862,
                       '2023-04-14',
                       '2023-04-24',
                       '2944 Sunny Glen Lane, Cleveland, OH, 44103'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '1133402801',
                       1,
                       5,
                       88952,
                       '2024-01-13',
                       '2024-01-09',
                       '3041 Hiddenview Drive, Cleveland, OH, 44114'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '2517877483',
                       3,
                       2,
                       56930,
                       '2023-05-24',
                       '2024-02-19',
                       '2639 Quilly Lane, Columbus, OH, 43215'
                   );

INSERT INTO Orders (
                       OrderNumber,
                       OrderType,
                       Quantity,
                       OrderValue,
                       EstimatedDateOfArrival,
                       ActualDateOfArrival,
                       WarehouseAddress
                   )
                   VALUES (
                       '7613677354',
                       3,
                       29,
                       95329,
                       '2023-09-13',
                       '2023-03-16',
                       '2573 James Martin Circle, Columbus, OH, 43085'
                   );


-- Table: RentalInstance
CREATE TABLE IF NOT EXISTS RentalInstance (
    ID            TEXT     PRIMARY KEY,
    RentedDate    DATETIME,
    ReturnDate    DATETIME,
    CalculatedFee FLOAT,
    DueDate       DATETIME,
    UserID        TEXT,
    FOREIGN KEY (
        UserID
    )
    REFERENCES Member (UserID) 
);

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '1035645807',
                               '2023-05-30',
                               '2023-06-09',
                               10.0,
                               '2023-09-29',
                               '704836076'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '5602634509',
                               '2023-07-30',
                               '2023-08-13',
                               28.6,
                               '2024-01-09',
                               '4738212443'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '6722920747',
                               '2023-07-10',
                               '2023-11-07',
                               14.9,
                               '2024-01-25',
                               '7697605201'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '8557186517',
                               '2023-03-20',
                               '2023-03-27',
                               11.5,
                               '2024-02-05',
                               '6883879358'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '3367340200',
                               '2023-07-04',
                               '2024-01-30',
                               9.1,
                               '2023-10-28',
                               '294301828'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '6480838653',
                               '2023-03-07',
                               '2023-07-26',
                               4.6,
                               '2024-01-16',
                               '5118878411'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '916646246',
                               '2023-05-15',
                               '2023-07-12',
                               7.7,
                               '2024-02-16',
                               '3140509375'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '7162685641',
                               '2023-04-03',
                               '2023-04-29',
                               5.8,
                               '2023-09-08',
                               '2075521808'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '6025499071',
                               '2023-03-22',
                               '2023-09-17',
                               6.3,
                               '2023-09-13',
                               '6737671829'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '664865615',
                               '2023-03-19',
                               '2023-05-31',
                               13.1,
                               '2023-08-08',
                               '5560365416'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '4246814024',
                               '2023-07-08',
                               '2023-11-28',
                               15.7,
                               '2024-02-25',
                               '1838735992'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '1397810114',
                               '2023-04-11',
                               '2023-10-11',
                               4.7,
                               '2024-01-09',
                               '7613430332'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '367145375',
                               '2023-05-15',
                               '2023-06-06',
                               1.8,
                               '2023-07-28',
                               '3093992079'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '3273421177',
                               '2023-05-24',
                               '2023-07-07',
                               28.9,
                               '2023-09-24',
                               '3101299349'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '1247343871',
                               '2023-06-10',
                               '2023-07-27',
                               9.2,
                               '2024-01-06',
                               '1552147452'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '7528478857',
                               '2023-04-20',
                               '2023-12-28',
                               2.7,
                               '2024-01-25',
                               '2374060969'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '4048634968',
                               '2023-04-10',
                               '2023-06-23',
                               4.5,
                               '2023-11-29',
                               '7519080234'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '245644903',
                               '2023-03-26',
                               '2023-04-18',
                               8.9,
                               '2023-12-20',
                               '6713337155'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '1244503509',
                               '2023-10-18',
                               '2023-10-26',
                               17.2,
                               '2023-12-16',
                               '9912576926'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '2309845728',
                               '2024-03-07',
                               '2024-03-10',
                               21.3,
                               '2024-03-08',
                               '9912576926'
                           );

INSERT INTO RentalInstance (
                               ID,
                               RentedDate,
                               ReturnDate,
                               CalculatedFee,
                               DueDate,
                               UserID
                           )
                           VALUES (
                               '182553175',
                               '2023-09-21',
                               '2023-10-21',
                               9.3,
                               '2024-01-20',
                               '399835598'
                           );


-- Table: Review
CREATE TABLE IF NOT EXISTS Review (
    ReviewID         TEXT     PRIMARY KEY,
    Content          TEXT,
    Rating           INT,
    ReviewedDate     DATETIME,
    UserID           TEXT,
    RentalInstanceID INT,
    ModelNumber      TEXT,
    Manufacturer     TEXT,
    FOREIGN KEY (
        UserID
    )
    REFERENCES Member (UserID),
    FOREIGN KEY (
        RentalInstanceID
    )
    REFERENCES RentalInstance (ID),
    FOREIGN KEY (
        ModelNumber,
        Manufacturer
    )
    REFERENCES EquipmentType (ModelNumber,
    Manufacturer) 
);

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '9876543210',
                       'I had a satisfactory experience with the product; it fulfilled most of my requirements.',
                       3,
                       '2024-03-07 08:15:23',
                       '2075521808',
                       7162685641,
                       '0',
                       'Paint4Fun'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '1234567890',
                       'The product exceeded my expectations, providing excellent features and functionality.',
                       1,
                       '2024-03-07 14:32:45',
                       '6883879358',
                       8557186517,
                       '4',
                       'Plumbing''r''Us'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '4567890123',
                       'The product is good, but there are some areas that could be improved for a better experience.',
                       4,
                       '2024-03-07 18:47:12',
                       '3101299349',
                       3273421177,
                       '2',
                       'GardenTogether'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '7890123456',
                       'I had an outstanding experience with the product, and it exceeded all my expectations.',
                       2,
                       '2024-03-07 09:26:58',
                       '5560365416',
                       664865615,
                       '6',
                       'StandardNetworks'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '2345678901',
                       'Unfortunately, the product didn''t meet my needs as it lacked essential features.',
                       5,
                       '2024-03-07 21:10:37',
                       '6737671829',
                       6025499071,
                       '2',
                       'Water!'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '5678901234',
                       'I had a satisfactory experience with the product; it fulfilled most of my requirements.',
                       1,
                       '2024-03-07 12:03:14',
                       '7519080234',
                       4048634968,
                       '5',
                       'ConstructionABC'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '8901234567',
                       'The product exceeded my expectations, providing excellent features and functionality.',
                       3,
                       '2024-03-07 16:28:09',
                       '6713337155',
                       245644903,
                       NULL,
                       'ElectricDance'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '3456789012',
                       'The product is good, but there are some areas that could be improved for a better experience.',
                       2,
                       '2024-03-07 07:55:21',
                       '4738212443',
                       5602634509,
                       '2',
                       'Poopers!'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '6789012345',
                       'I had an outstanding experience with the product, and it exceeded all my expectations.',
                       4,
                       '2024-03-07 19:39:44',
                       '399835598',
                       182553175,
                       '0',
                       'Paint4Fun'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '9012345678',
                       'Unfortunately, the product didn''t meet my needs as it lacked essential features.',
                       5,
                       '2024-03-07 11:14:36',
                       '7697605201',
                       6722920747,
                       '4',
                       'Plumbing''r''Us'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '5432109876',
                       'I had a satisfactory experience with the product; it fulfilled most of my requirements.',
                       1,
                       '2024-03-07 13:48:59',
                       '7613430332',
                       1397810114,
                       '2',
                       'GardenTogether'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '2109876543',
                       'The product exceeded my expectations, providing excellent features and functionality.',
                       3,
                       '2024-03-07 22:04:27',
                       '1838735992',
                       4246814024,
                       '6',
                       'StandardNetworks'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '8765432109',
                       'The product is good, but there are some areas that could be improved for a better experience.',
                       2,
                       '2024-03-07 17:12:03',
                       '1552147452',
                       1247343871,
                       '2',
                       'Water!'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '3210987654',
                       'I had an outstanding experience with the product, and it exceeded all my expectations.',
                       4,
                       '2024-03-07 10:21:50',
                       '3140509375',
                       916646246,
                       '5',
                       'ConstructionABC'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '4321098765',
                       'Unfortunately, the product didn''t meet my needs as it lacked essential features.',
                       5,
                       '2024-03-07 23:37:18',
                       '6883879358',
                       8557186517,
                       NULL,
                       'ElectricDance'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '1098765432',
                       'I had a satisfactory experience with the product; it fulfilled most of my requirements.',
                       1,
                       '2024-03-07 15:05:42',
                       '294301828',
                       3367340200,
                       '2',
                       'Poopers!'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '7654321098',
                       'The product exceeded my expectations, providing excellent features and functionality.',
                       3,
                       '2024-03-07 20:53:06',
                       '3101299349',
                       3093992079,
                       '0',
                       'Paint4Fun'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '6543210987',
                       'The product is good, but there are some areas that could be improved for a better experience.',
                       2,
                       '2024-03-07 06:42:29',
                       '6883879358',
                       8557186517,
                       '4',
                       'Plumbing''r''Us'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '9876543211',
                       'I had an outstanding experience with the product, and it exceeded all my expectations.',
                       4,
                       '2024-03-07 05:19:04',
                       '5560365416',
                       6737671829,
                       '2',
                       'GardenTogether'
                   );

INSERT INTO Review (
                       ReviewID,
                       Content,
                       Rating,
                       ReviewedDate,
                       UserID,
                       RentalInstanceID,
                       ModelNumber,
                       Manufacturer
                   )
                   VALUES (
                       '8901234568',
                       'Unfortunately, the product didn''t meet my needs as it lacked essential features.',
                       5,
                       '2024-03-07 03:31:50',
                       '1552147452',
                       1247343871,
                       '6',
                       'StandardNetworks'
                   );


-- Table: Trip
CREATE TABLE IF NOT EXISTS Trip (
    ID                   TEXT     PRIMARY KEY,
    DepartureDate        DATETIME,
    ArrivalDate          DATETIME,
    PickupOrDelivery     INT,-- 0 if pickup, 1 if delivery
    TransportationMethod INT,-- 0 if drone, 1 if truck
    UserID               TEXT,
    WarehouseAddress     TEXT,
    DroneSerialNumber    TEXT,
    TruckLicensePlate    TEXT,
    FOREIGN KEY (
        UserID
    )
    REFERENCES Member (UserID),
    FOREIGN KEY (
        WarehouseAddress
    )
    REFERENCES Warehouse (WarehouseAddress),
    FOREIGN KEY (
        DroneSerialNumber
    )
    REFERENCES Drone (SerialNumber),
    FOREIGN KEY (
        TruckLicensePlate
    )
    REFERENCES Truck (LicensePlate) 
);

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '4961959502',
                     '2023-05-21',
                     '2024-01-16',
                     0,
                     0,
                     '7519080234',
                     '2639 Quilly Lane, Columbus, OH, 43215',
                     'M7cPBxV5Eb',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '1490151184',
                     '2024-02-05',
                     '2023-06-23',
                     0,
                     0,
                     '1838735992',
                     '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                     'hhznaFc5rX',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '6099674810',
                     '2023-03-29',
                     '2023-11-29',
                     0,
                     0,
                     '6883879358',
                     '2573 James Martin Circle, Columbus, OH, 43085',
                     'JKcGkMWfoT',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '2935962044',
                     '2023-12-22',
                     '2023-08-25',
                     0,
                     0,
                     '6737671829',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     '8aHr6xzxRj',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '2715443269',
                     '2023-11-01',
                     '2023-08-18',
                     0,
                     0,
                     '4738212443',
                     '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                     '6n2cxxyCv7',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '5741719163',
                     '2023-12-02',
                     '2023-06-20',
                     0,
                     0,
                     '3140509375',
                     '1516 Ingram Street, Dayton, OH, 45408',
                     '9FMtD8EMke',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '770153283',
                     '2024-01-31',
                     '2023-09-18',
                     0,
                     0,
                     '1552147452',
                     '2573 James Martin Circle, Columbus, OH, 43085',
                     '8WPTezcKUG',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '7172825039',
                     '2024-01-13',
                     '2024-02-09',
                     0,
                     0,
                     '5118878411',
                     '3041 Hiddenview Drive, Cleveland, OH, 44114',
                     'wYbszcsdoC',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '5890504436',
                     '2023-12-16',
                     '2023-10-20',
                     1,
                     0,
                     '2075521808',
                     '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                     'EpAKGmpSo2',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '986573809',
                     '2023-08-07',
                     '2023-11-20',
                     1,
                     0,
                     '7613430332',
                     '109 Andell Road, Columbus, OH, 43215',
                     'PGdChXkjaM',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '3744605574',
                     '2023-04-12',
                     '2023-12-29',
                     0,
                     0,
                     '399835598',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     'FADnceUKZS',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '3993956931',
                     '2024-01-15',
                     '2023-12-21',
                     0,
                     0,
                     '5560365416',
                     '1516 Ingram Street, Dayton, OH, 45408',
                     '9FMtD8EMke',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '3612612255',
                     '2023-06-18',
                     '2023-06-06',
                     0,
                     0,
                     '704836076',
                     '2573 James Martin Circle, Columbus, OH, 43085',
                     'cJS8TJeiLK',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '967300614',
                     '2023-11-29',
                     '2023-06-11',
                     1,
                     0,
                     '294301828',
                     '2639 Quilly Lane, Columbus, OH, 43215',
                     'SqDZxbvgSi',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '2727186223',
                     '2023-07-27',
                     '2023-04-18',
                     0,
                     0,
                     '1552147452',
                     '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                     '6n2cxxyCv7',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '3290396800',
                     '2023-05-24',
                     '2023-08-03',
                     0,
                     1,
                     '3101299349',
                     '2573 James Martin Circle, Columbus, OH, 43085',
                     NULL,
                     '4Yar9JS2hM'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '4880312460',
                     '2023-10-16',
                     '2023-04-15',
                     1,
                     1,
                     '3093992079',
                     '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                     NULL,
                     'mwkh3mQaCQ'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '3422969098',
                     '2023-06-27',
                     '2023-04-04',
                     0,
                     1,
                     '6713337155',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     NULL,
                     'JKcGkMWfoT'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '8567773628',
                     '2023-12-29',
                     '2024-01-16',
                     1,
                     1,
                     '399835598',
                     '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                     NULL,
                     'Q2fpSQ7XuQ'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '9223852552',
                     '2023-03-14',
                     '2023-12-31',
                     1,
                     1,
                     '294301828',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     NULL,
                     'qySBK79viH'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '8273792625',
                     '2023-11-15',
                     '2023-07-21',
                     1,
                     1,
                     '2075521808',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     NULL,
                     '6n2cxxyCv7'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '2541466676',
                     '2023-07-31',
                     '2023-05-09',
                     1,
                     1,
                     '4738212443',
                     '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                     NULL,
                     'M7cPBxV5Eb'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '107849348',
                     '2023-10-13',
                     '2023-04-16',
                     0,
                     1,
                     '2374060969',
                     '2573 James Martin Circle, Columbus, OH, 43085',
                     NULL,
                     '5BokQYhdTE'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '8033754141',
                     '2023-06-22',
                     '2023-05-15',
                     0,
                     1,
                     '2374060969',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     NULL,
                     '9FMtD8EMke'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '6736247853',
                     '2023-08-27',
                     '2023-06-02',
                     1,
                     1,
                     '704836076',
                     '1516 Ingram Street, Dayton, OH, 45408',
                     NULL,
                     'pwtPLi4iCk'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '7210031340',
                     '2023-03-08',
                     '2023-05-22',
                     1,
                     1,
                     '5118878411',
                     '2639 Quilly Lane, Columbus, OH, 43215',
                     NULL,
                     'AsvxDibjDT'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '7930053660',
                     '2023-08-04',
                     '2023-05-12',
                     0,
                     1,
                     '1838735992',
                     '109 Andell Road, Columbus, OH, 43215',
                     NULL,
                     'onpB67DCz7'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '1414171471',
                     '2023-05-06',
                     '2023-04-19',
                     0,
                     1,
                     '7697605201',
                     '2639 Quilly Lane, Columbus, OH, 43215',
                     NULL,
                     'MHxK4HNcbC'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '2045205967',
                     '2023-06-27',
                     '2023-08-11',
                     1,
                     1,
                     '6737671829',
                     '2573 James Martin Circle, Columbus, OH, 43085',
                     NULL,
                     'AugQEw8AG6'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '4413909577',
                     '2024-02-19',
                     '2024-03-06',
                     0,
                     1,
                     '6713337155',
                     '2639 Quilly Lane, Columbus, OH, 43215',
                     NULL,
                     '8aHr6xzxRj'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '9819652340',
                     '2023-03-18',
                     '2023-05-28',
                     1,
                     1,
                     '7697605201',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     NULL,
                     '9FMtD8EMke'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '5462645120',
                     '2023-11-15',
                     '2023-06-15',
                     0,
                     1,
                     '3140509375',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     NULL,
                     'JKcGkMWfoT'
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '5027834462',
                     '2023-03-30',
                     '2024-02-12',
                     0,
                     0,
                     '3093992079',
                     '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                     'xhywCWdXiG',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '612031772',
                     '2023-11-21',
                     '2023-03-30',
                     1,
                     0,
                     '6883879358',
                     '2639 Quilly Lane, Columbus, OH, 43215',
                     'Yy3f34XJAr',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '4357956498',
                     '2024-01-23',
                     '2023-04-30',
                     1,
                     0,
                     '7613430332',
                     '109 Andell Road, Columbus, OH, 43215',
                     'MHxK4HNcbC',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '795751184',
                     '2023-08-01',
                     '2023-08-22',
                     1,
                     0,
                     '9912576926',
                     '2639 Quilly Lane, Columbus, OH, 43215',
                     'SqDZxbvgSi',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '182151867',
                     '2023-11-18',
                     '2024-01-05',
                     0,
                     0,
                     '9912576926',
                     '3041 Hiddenview Drive, Cleveland, OH, 44114',
                     'jbAEjsXPs3',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '2879818796',
                     '2023-06-01',
                     '2023-08-29',
                     1,
                     0,
                     '3101299349',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     '1111111111',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '2718443731',
                     '2023-03-07',
                     '2023-10-11',
                     0,
                     0,
                     '5560365416',
                     '4249 Pringle Drive, Dayton, OH, 45469',
                     '8aHr6xzxRj',
                     NULL
                 );

INSERT INTO Trip (
                     ID,
                     DepartureDate,
                     ArrivalDate,
                     PickupOrDelivery,
                     TransportationMethod,
                     UserID,
                     WarehouseAddress,
                     DroneSerialNumber,
                     TruckLicensePlate
                 )
                 VALUES (
                     '4954852765',
                     '2024-01-06',
                     '2023-10-27',
                     0,
                     0,
                     '7519080234',
                     '3041 Hiddenview Drive, Cleveland, OH, 44114',
                     'jbAEjsXPs3',
                     NULL
                 );


-- Table: Truck
CREATE TABLE IF NOT EXISTS Truck (
    LicensePlate     TEXT PRIMARY KEY,
    ModelNumber      TEXT,
    TruckYear        INT,
    TruckStatus      INT,-- 0 if inactive, 1 if active
    WarehouseAddress TEXT,
    OrderNumber      TEXT,
    FOREIGN KEY (
        ModelNumber
    )
    REFERENCES TruckSpecs (ModelNumber),
    FOREIGN KEY (
        WarehouseAddress
    )
    REFERENCES Warehouse (WarehouseAddress),
    FOREIGN KEY (
        OrderNumber
    )
    REFERENCES Orders (OrderNumber) 
);

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'M7cPBxV5Eb',
                      'Titan Hauler',
                      1980,
                      1,
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '1234567890'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'PGdChXkjaM',
                      'RidgeMaster XLT',
                      1988,
                      1,
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '2345678901'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '3t5T9qfEJZ',
                      'ThunderTrail Pro',
                      1999,
                      0,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '3456789012'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'EpAKGmpSo2',
                      'TurboTruck Elite',
                      2012,
                      0,
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '4567890123'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'iFsKGUKtVm',
                      'GraniteGrip LX',
                      1994,
                      0,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '5678901234'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '5BokQYhdTE',
                      'TimberTrek Max',
                      2005,
                      1,
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '6789012345'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'xhywCWdXiG',
                      'FalconForce HD',
                      2009,
                      1,
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '7890123456'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'hhznaFc5rX',
                      'Maverick Hauler',
                      1993,
                      1,
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '8901234567'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '3EYec67gDT',
                      'PowerLift Xpress',
                      2004,
                      0,
                      '109 Andell Road, Columbus, OH, 43215',
                      '9012345678'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'jbAEjsXPs3',
                      'SummitTrail Pro',
                      1999,
                      0,
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '9876543210'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '4Yar9JS2hM',
                      'VortexMax Ultra',
                      2006,
                      0,
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '8765432109'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'Uw5ri3cCTA',
                      'ThunderHawk X5',
                      2009,
                      1,
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '7654321098'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'UJm6nr3qBr',
                      'DeltaForce Elite',
                      1998,
                      0,
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '6543210987'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'wYbszcsdoC',
                      'ApexHaul Max',
                      1994,
                      1,
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '5432109876'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'Yy3f34XJAr',
                      'SilverLift Titan',
                      1994,
                      0,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '4321098765'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'HgoaLAheW9',
                      'ProTruck Thunder',
                      2011,
                      1,
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '3210987654'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'rpFKbzktsP',
                      'TrailBlazer XL',
                      2004,
                      0,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '2109876543'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'FADnceUKZS',
                      'GranitePeak Titan',
                      1988,
                      0,
                      '3041 Hiddenview Drive, Cleveland, OH, 44114',
                      '1098765432'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'mwkh3mQaCQ',
                      'TimberMax Pro',
                      2001,
                      1,
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '9870123456'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'jjNbW8E4AM',
                      'MaverickTrail Elite',
                      1991,
                      0,
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '8769012345'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'MHxK4HNcbC',
                      'ThunderStorm XLT',
                      2006,
                      0,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '7658901234'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '9FMtD8EMke',
                      'TurboHaul Max',
                      2008,
                      1,
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '6547890123'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'JKcGkMWfoT',
                      'FalconTruck Elite',
                      2012,
                      1,
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '5436789012'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'C5x4TEr4jU',
                      'RidgeTrek HD',
                      2013,
                      1,
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '4325678901'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '4zduDv2ga3',
                      'PowerLift Pro',
                      1985,
                      1,
                      '109 Andell Road, Columbus, OH, 43215',
                      '3214567890'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '8WPTezcKUG',
                      'TimberHawk Ultra',
                      1997,
                      0,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '2103456789'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'xvQMBcC7wF',
                      'SummitForce HDX',
                      2012,
                      0,
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '1092345678'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'AugQEw8AG6',
                      'VortexHaul Xpress',
                      2011,
                      1,
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '9877654321'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'SqDZxbvgSi',
                      'GraniteTrail Elite',
                      2002,
                      1,
                      '109 Andell Road, Columbus, OH, 43215',
                      '8766543210'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'Q2fpSQ7XuQ',
                      'DeltaHawk Max',
                      1996,
                      0,
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '7655432109'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '8aHr6xzxRj',
                      'TimberForce X5',
                      2011,
                      1,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '6544321098'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'PZYn4M2C6X',
                      'RidgeMax Ultra',
                      1983,
                      0,
                      '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                      '5433210987'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'NHcwQM7e3Z',
                      'ApexHawk Pro',
                      2010,
                      0,
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '4322109876'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'qySBK79viH',
                      'ThunderLift XLT',
                      1993,
                      1,
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '3211098765'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'AsvxDibjDT',
                      'MaverickTrail Max',
                      2002,
                      0,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '2100987654'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'pwtPLi4iCk',
                      'ProTruck Xpress',
                      2011,
                      1,
                      '1516 Ingram Street, Dayton, OH, 45408',
                      '1099876543'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      '6n2cxxyCv7',
                      'TrailBlazer HD',
                      2007,
                      1,
                      '4249 Pringle Drive, Dayton, OH, 45469',
                      '9876543210'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'cJS8TJeiLK',
                      'GraniteStorm Pro',
                      1998,
                      1,
                      '2639 Quilly Lane, Columbus, OH, 43215',
                      '8765432109'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'onpB67DCz7',
                      'TimberLift Titan',
                      1984,
                      0,
                      '109 Andell Road, Columbus, OH, 43215',
                      '7654321098'
                  );

INSERT INTO Truck (
                      LicensePlate,
                      ModelNumber,
                      TruckYear,
                      TruckStatus,
                      WarehouseAddress,
                      OrderNumber
                  )
                  VALUES (
                      'J63haYf29H',
                      'PowerHawk Elite',
                      1992,
                      1,
                      '2573 James Martin Circle, Columbus, OH, 43085',
                      '6543210987'
                  );


-- Table: TruckSpecs
CREATE TABLE IF NOT EXISTS TruckSpecs (
    ModelNumber     TEXT  PRIMARY KEY,
    WeightCapacity  FLOAT,
    StorageCapacity FLOAT
);

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'TimberForce X5',
                           10.0,
                           500.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'RidgeTrek HD',
                           12.0,
                           600.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'ApexHawk Pro',
                           8.0,
                           400.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'VortexMax HDX',
                           15.0,
                           750.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'SilverLift Titan',
                           14.0,
                           700.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'TurboHaul Max',
                           18.0,
                           900.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'ThunderLift XLT',
                           11.0,
                           550.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'GraniteTrail Elite',
                           13.0,
                           650.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'DeltaHawk Max',
                           16.0,
                           800.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'FalconForce HD',
                           20.0,
                           1000.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'MaverickTrail Elite',
                           17.0,
                           850.0
                       );

INSERT INTO TruckSpecs (
                           ModelNumber,
                           WeightCapacity,
                           StorageCapacity
                       )
                       VALUES (
                           'ProTruck Thunder',
                           22.0,
                           1100.0
                       );


-- Table: Warehouse
CREATE TABLE IF NOT EXISTS Warehouse (
    WarehouseAddress TEXT PRIMARY KEY,
    PhoneNumber      TEXT,
    StorageCapacity  INT,
    Manager          TEXT,
    DroneCapacity    INT,
    TruckCapacity    INT,
    City             TEXT
);

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '2639 Quilly Lane, Columbus, OH, 43215',
                          '6145856299',
                          213,
                          'Ignace Chatelet',
                          91,
                          10,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '109 Andell Road, Columbus, OH, 43215',
                          '6149300109',
                          199,
                          'Marnia Genn',
                          70,
                          15,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '2573 James Martin Circle, Columbus, OH, 43085',
                          '6143672630',
                          198,
                          'Sibelle Hazeltine',
                          92,
                          13,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '1516 Ingram Street, Dayton, OH, 45408',
                          '9374705168',
                          153,
                          'Hester Kyne',
                          52,
                          9,
                          'Dayton'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '4249 Pringle Drive, Dayton, OH, 45469',
                          '9377811636',
                          165,
                          'Caralie Coucher',
                          85,
                          4,
                          'Dayton'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '3041 Hiddenview Drive, Cleveland, OH, 44114',
                          '2162079167',
                          168,
                          'Sollie Areles',
                          56,
                          21,
                          'Cleveland'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '2944 Sunny Glen Lane, Cleveland, OH, 44103',
                          '2168815347',
                          155,
                          'Rochell Vineall',
                          73,
                          17,
                          'Cleveland'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '61 Cordelia Alley, Columbus, OH, 43210',
                          '6997308606',
                          161,
                          'Bogart Boshers',
                          99,
                          5,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '810 Mifflin Drive, Columbus, OH, 43210',
                          '1483690362',
                          141,
                          'Katherine Cometto',
                          99,
                          6,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '9743 Hallows Parkway, Columbus, OH, 43210',
                          '4195518895',
                          221,
                          'Nona Shanks',
                          100,
                          14,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '89895 Anthes Avenue, Columbus, OH, 43210',
                          '5007634797',
                          214,
                          'Arne Shorthill',
                          75,
                          17,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '2555 Shasta Pass, Columbus, OH, 43210',
                          '7086629325',
                          241,
                          'Lacee Gallamore',
                          56,
                          14,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '5 Clyde Gallagher Crossing, Columbus, OH, 43210',
                          '2233425382',
                          129,
                          'Thurston Bartholat',
                          92,
                          14,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '328 Sutherland Park, Columbus, OH, 43210',
                          '7645764208',
                          139,
                          'Giordano Ruppertz',
                          71,
                          14,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '24323 Everett Lane, Columbus, OH, 43210',
                          '4116902028',
                          198,
                          'Lincoln Ody',
                          93,
                          9,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '9 Oriole Plaza, Columbus, OH, 43210',
                          '2677951193',
                          169,
                          'Kori Priden',
                          99,
                          20,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '91676 High Crossing Alley, Columbus, OH, 43210',
                          '3729532699',
                          137,
                          'Jackelyn Lowndsbrough',
                          75,
                          11,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '197 Laurel Street, Columbus, OH, 43210',
                          '1607920652',
                          154,
                          'Mitchael Doers',
                          91,
                          7,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '8285 Meadow Ridge Lane, Columbus, OH, 43210',
                          '8989660574',
                          234,
                          'Faun Dubose',
                          93,
                          8,
                          'Columbus'
                      );

INSERT INTO Warehouse (
                          WarehouseAddress,
                          PhoneNumber,
                          StorageCapacity,
                          Manager,
                          DroneCapacity,
                          TruckCapacity,
                          City
                      )
                      VALUES (
                          '8 Gulseth Avenue, Columbus, OH, 43210',
                          '3183911554',
                          192,
                          'Iago Mundie',
                          75,
                          15,
                          'Columbus'
                      );


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
