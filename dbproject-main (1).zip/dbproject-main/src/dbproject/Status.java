package dbproject;

public enum Status {
    ACTIVE, INACTIVE
}
