package dbproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class Database {

    private static Connection connection = null;

    /**
     * Initialize the database connection using SQLite.
     * This method should be called before any other database operations.
     */
    public static void initialize() {
        // Hardcoded database URL for SQLite
        var databaseUrl = "jdbc:sqlite:project.db";

        try {
            // Create a connection to the database
            connection = DriverManager.getConnection(databaseUrl);

            // Check if the connection is successful
            if (connection == null) {
                // Print an error message if the connection fails
                System.err.println("Failed to make connection.");
            }
            System.out.println("Connected.");
        } catch (SQLException e) {
            // Print the error message if something goes wrong
            System.err.println(e.getMessage());
        }
    }

    /**
     * Execute an update to the database, for example {@code INSERT},
     * {@code UPDATE}, {@code DELETE}.
     * 
     * @param sql  The SQL query to execute.
     * @param args Optional varargs to pass to the query using SQL {@code ?}
     *             placeholders.
     */
    public static void update(String sql, Object... args) {
        try {
            // Use a prepared statement (to prevent SQL injection)
            var statement = connection.prepareStatement(sql);

            // Add in the arguments (if there are any)
            for (var i = 0; i < args.length; i++) {
                statement.setObject(i + 1, args[i]);
            }

            // actually execute the query
            statement.executeUpdate();
        } catch (SQLException e) {
            // Print the error message if something goes wrong
            System.err.println(e.getMessage());
        }
    }

    /**
     * Query the database and return a list of records, for example {@code SELECT}.
     * 
     * @param <T>   Automatically inferred type of the record to return from
     *              {@code clazz}.
     * @param clazz The class of the record to return. The order of the fields in
     *              the record should match the order of the columns in the SQL
     *              query, with the correct respective types.
     * @param sql   The SQL query to execute.
     * @param args  Optional varargs to pass to the query using SQL {@code ?}
     *              placeholders.
     * @return A list of records of the specified record.
     */
    public static <T> List<T> query(Class<T> clazz, String sql, Object... args) {
        // Create a new list to store the results
        var results = new ArrayList<T>();

        // Use reflection to get the types of the constructor parameters, which for a
        // record are the fields. We will use these later to cast the database types
        // into the correct Java types.
        var constructor = clazz.getDeclaredConstructors()[0];
        var types = constructor.getParameterTypes();

        try {
            // Use a prepared statement (to prevent SQL injection)
            var statement = connection.prepareStatement(sql);

            // Add in the arguments (if there are any)
            for (var i = 0; i < args.length; i++) {
                statement.setObject(i + 1, args[i]);
            }

            // Execute the query and get the results
            try (ResultSet resultSet = statement.executeQuery()) {
                // Iterate over the results
                while (resultSet.next()) {
                    // Create a new generic `Object` array to store the current row
                    Object[] row = new Object[resultSet.getMetaData().getColumnCount()];
                    for (int i = 0; i < row.length; i++) {
                        row[i] = resultSet.getObject(i + 1);
                    }

                    // Go through every type in the constructor and cast the database type, which is
                    // currently a generic Object, into the correct Java type
                    for (int i = 0; i < types.length; i++) {
                        var type = types[i];
                        row[i] = switch (type.getName()) {
                            case "int" -> Integer.parseInt(row[i].toString());
                            case "float" -> Float.parseFloat(row[i].toString());
                            case "double" -> Double.parseDouble(row[i].toString());
                            case "java.lang.String" -> row[i].toString();

                            // Default set to minimum date if parsing fails.
                            // This handles weird edges cases like for `epicdropn`
                            // in our seed data where the date is `1`.
                            case "java.time.LocalDate" -> {
                                try {
                                    yield LocalDate.parse(row[i].toString());
                                } catch (DateTimeParseException e) {
                                    yield LocalDate.MIN;
                                }
                            }

                            default -> {
                                System.err.println("Cannot cast database type " + row[i].getClass().getName() + " into "
                                        + type.getName());
                                yield row[i];
                            }
                        };
                    }

                    // Now that we've transformed the row into the (hopefully) correct types, we can
                    // call the constructor to create a new record safely and insert it into our
                    // returned results.
                    @SuppressWarnings("unchecked")
                    T x = (T) constructor.newInstance(row);
                    results.add(x);
                }
            }
        } catch (Exception e) {
            // Print the error message if something goes wrong
            e.printStackTrace();
        }

        // Return the list of results, which may be empty if no results were found or an
        // error occurred
        return results;
    }

    public static <T> void printRecordList(List<T> list) {
        if (list.isEmpty()) {
            System.out.println("List is empty.");
            return;
        }

        // use Java reflection to get the record components
        var clazz = list.get(0).getClass();
        var components = clazz.getRecordComponents();

        if (components.length == 0) {
            System.out.println("No record components found in class.");
            return;
        }

        var headers = new String[components.length];
        var table = new String[list.size()][components.length];

        // change all headers to PascalCase so they look nice
        for (int i = 0; i < components.length; i++) {
            headers[i] = toPascalCase(components[i].getName());
        }

        // build the table by accessing the record components using reflection
        for (int i = 0; i < list.size(); i++) {
            T item = list.get(i);
            for (int j = 0; j < components.length; j++) {
                try {
                    Object value = components[j].getAccessor().invoke(item);
                    table[i][j] = value.toString();
                } catch (ReflectiveOperationException e) {
                    System.out.println("Error accessing component: " + e.getMessage());
                }
            }
        }

        printTable(headers, table);
    }

    private static void printTable(String[] headers, String[][] table) {
        // calculate the maximum width of each column
        var maxWidths = new int[headers.length];
        for (int i = 0; i < headers.length; i++) {
            maxWidths[i] = headers[i].length();
            for (var row : table) {
                maxWidths[i] = Math.max(maxWidths[i], row[i].length());
            }
        }

        // print the rows, keeping in mind the maximum width of each column
        printRow(headers, maxWidths);
        for (var row : table) {
            printRow(row, maxWidths);
        }
    }

    private static void printRow(String[] row, int[] maxWidths) {
        for (int i = 0; i < row.length; i++) {
            System.out.print(padRight(row[i], maxWidths[i] + 2)); // Add extra padding for readability
        }
        System.out.println();
    }

    private static String padRight(String s, int width) {
        return String.format("%-" + width + "s", s);
    }

    private static String toPascalCase(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

}
