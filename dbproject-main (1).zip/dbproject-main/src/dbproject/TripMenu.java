package dbproject;

public class TripMenu {
    public static void menu() {
        var inMenu = true;
        while (inMenu) {
            System.out.print("""
                    Trip Actions
                    1) List Trips
                    2) Deliver Equipment
                    3) Pickup Equipment
                    4) Exit
                    Selection?""" + " ");
            var selection = Main.scanner.nextInt();
            Main.scanner.nextLine(); // consume the newline
            System.out.println();

            switch (selection) {
                case 1 -> listTrips();
                case 2 -> transportEquipment(1);
                case 3 -> transportEquipment(0);
                case 4 -> inMenu = false;
                default -> System.out.println("Invalid selection");
            }
        }
    }

    private static void placeholder() {
        System.out.println("Functionality not yet added.");
    }

    private static void listTrips() {
        placeholder();
    }

    private static void transportEquipment(int pickupOrDelivery) {
        if(pickupOrDelivery == 0) {
        	System.out.println("Pickup Equipment");
            System.out.println("Specify Equipment to pickup");
        }else {
        	System.out.println(" Deliver ");
            System.out.println("Specify Equipment to deliver");
        }
        var equipmentId = Questionnaire.askString("Equipment Serial Number", null, (value) -> value.length() > 0);
        var equipmentManufacturer = Questionnaire.askString("Equipment Manufacturer", null,
                (value) -> value.length() > 0);
        
        System.out.println("Specify Rental Instance to fulfill");
        var rentalID = Questionnaire.askString("Rental Instance", null, (value) -> value.length() > 0);
        
        System.out.println("Specify Trip Details");

        var tripID = Questionnaire.askString("Trip ID", null, (value) -> value.length() > 0);
        var departureDate =  Questionnaire.askDate("Departure Date", null, (value) -> true);
        var arrivalDate = Questionnaire.askDate("Arrival Date", null, (value) -> true);
        var memberId = Questionnaire.askString("Member ID", null, (value) -> value.length() > 0);
        var warehouseAddress = Questionnaire.askString("Address of Dispatching Warehouse", null, (value) -> true);
        
        var transportationMethod = Questionnaire.askInt("Transportation method (0 for Drone, 1 for Truck)", null, (value) -> value == 0 | value == 1);
        
        
        if (transportationMethod == 1) {
        	//TRUCK CASE
        	var truckLicensePlate = Questionnaire.askString("Truck License Plate", null, (value) -> value.length() > 0);
        	//CarriedIN
            Database.update("""
                    INSERT INTO CarriedIn VALUES (?,?,?)
                    """, equipmentId, equipmentManufacturer, tripID);
            //FUFILL
            Database.update("""
                    INSERT INTO FULFILL VALUES (?,?)
                    """, rentalID, tripID);
        	//TRUCK CASE
        	Database.update("""
                    INSERT INTO TRIP VALUES (?,?,?,?,?,?,?,?,?)
                    """, tripID, departureDate, arrivalDate, pickupOrDelivery, transportationMethod, memberId, warehouseAddress, null, truckLicensePlate);
        	
        	System.out.print("Using Drone " + truckLicensePlate + " to");
        }else {
        	//DRONE CASE
        	var droneSerialNumber = Questionnaire.askString("Drone Serial Number", null, (value) -> value.length() > 0);
        	//CarriedIN
            Database.update("""
                    INSERT INTO CarriedIn VALUES (?,?,?)
                    """, equipmentId, equipmentManufacturer, tripID);
            //FUFILL
            Database.update("""
                    INSERT INTO FULFILL VALUES (?,?)
                    """, rentalID, tripID);
        	//TRUCK CASE
        	Database.update("""
                    INSERT INTO TRIP VALUES (?,?,?,?,?,?,?,?,?)
                    """, tripID, departureDate, arrivalDate, pickupOrDelivery, transportationMethod, memberId, warehouseAddress, droneSerialNumber, null);
        	System.out.print("Using Drone " + droneSerialNumber + " to");
        }
        
        if(pickupOrDelivery == 0) {
        	System.out.println(" Pickup ");
        }else {
        	System.out.println(" Deliver ");
        }
        
        System.out.println("Equipment "+ equipmentManufacturer + " " + equipmentId + " to member " + memberId + " For Rental ID " + rentalID);
    }
}
