package dbproject;

import java.time.LocalDate;

public class DroneMenu {

    // Mirrors the database schema for the Drone table
    // but with Java types.
    record Drone(
            String serialNumber,
            String droneName,
            int droneStatus,
            int droneAvailable,
            String droneLocation,
            LocalDate warrantyExpirationDate,
            String modelNumber,
            String manufacturer,
            String warehouseAddress,
            String orderNumber) {
    }

    public static void menu() {
        var inMenu = true;
        while (inMenu) {
            System.out.print("""
                    Drone Actions
                    1) New Drone
                    2) Edit Drone
                    3) List Drones
                    4) Search Drones
                    5) Delete Drone
                    6) Exit
                    Selection?""" + " ");
            var selection = Main.scanner.nextInt();
            Main.scanner.nextLine(); // consume the newline
            System.out.println();

            switch (selection) {
                case 1 -> newDroneMenu();
                case 2 -> editDroneMenu();
                case 3 -> listDrones();
                case 4 -> searchDrones();
                case 5 -> deleteDrone();
                case 6 -> inMenu = false;
                default -> System.out.println("Invalid selection");
            }
        }
    }

    private static void newDroneMenu() {
        System.out.println("Create a new Drone");

        var serialNumber = Questionnaire.askString("Serial Number", null, (value) -> !value.isBlank());
        var droneName = Questionnaire.askString("Name", null, (value) -> !value.isBlank());
        var status = Questionnaire.askInt("Status (0,1)", 1, (value) -> value == 0 || value == 1);
        var droneAvailable = Questionnaire.askInt("Available (0,1)", 1, (value) -> value == 0 || value == 1);
        var droneLocation = Questionnaire.askString("Location", null, (value) -> !value.isBlank());
        var warrantyExpirationDate = Questionnaire.askDate("Warranty Expiration Date (yyyy-MM-dd)", null,
                (value) -> true);
        var modelNumber = Questionnaire.askString("Model Number", null, (value) -> !value.isBlank());
        var manufacturer = Questionnaire.askString("Manufacturer", null, (value) -> !value.isBlank());
        var warehouseAddress = Questionnaire.askString("Warehouse Address", null, (value) -> !value.isBlank());
        var orderNumber = Questionnaire.askString("Order Number", null, (value) -> !value.isBlank());

        Database.update("INSERT INTO Drone VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", serialNumber, droneName,
                status, droneAvailable, droneLocation, warrantyExpirationDate, modelNumber, manufacturer, warehouseAddress, orderNumber);

        System.out.println("Drone successfully created\n");
    }

    private static void editDroneMenu() {
        System.out.println("Edit for a drone");

        var serialNumber = Questionnaire.askString("Serial Number", null, (value) -> !value.isBlank());
        var drone = Database.query(Drone.class, "SELECT * FROM Drone WHERE SerialNumber = ?", serialNumber).stream()
                .findFirst().orElse(null);
        if (drone == null) {
            System.out.println("Drone not found\n");
            return;
        }

        var newSerialNumber = Questionnaire.askString("Serial Number", drone.serialNumber(),
                (value) -> !value.isBlank());
        var droneName = Questionnaire.askString("Name", drone.droneName(), (value) -> !value.isBlank());
        var droneStatus = Questionnaire.askInt("Status (0,1)", drone.droneStatus(),
                (value) -> value == 0 || value == 1);
        var droneAvailable = Questionnaire.askInt("Available (0,1)", drone.droneAvailable(),
                (value) -> value == 0 || value == 1);
        var droneLocation = Questionnaire.askString("Location", drone.droneLocation(), (value) -> !value.isBlank());
        var warrantyExpirationDate = Questionnaire.askDate("Warranty Expiration Date (yyyy-MM-dd)",
                drone.warrantyExpirationDate(),
                (value) -> true);
        var modelNumber = Questionnaire.askString("Model Number", drone.modelNumber(), (value) -> !value.isBlank());
        var manufacturer = Questionnaire.askString("Manufacturer", drone.manufacturer(), (value) -> !value.isBlank());
        var warehouseAddress = Questionnaire.askString("Warehouse Address", drone.warehouseAddress(),
                (value) -> !value.isBlank());
        var orderNumber = Questionnaire.askString("Order Number", drone.orderNumber(), (value) -> !value.isBlank());

        Database.update(
                """
                        UPDATE Drone SET
                            SerialNumber = ?,
                            DroneName = ?,
                            DroneStatus = ?,
                            DroneAvailable = ?,
                            DroneLocation = ?,
                            WarrantyExpirationDate = ?,
                            ModelNumber = ?,
                            Manufacturer = ?,
                            WarehouseAddress = ?,
                            OrderNumber = ?
                        WHERE SerialNumber = ?
                                        """,
                newSerialNumber, droneName, droneStatus, droneAvailable, droneLocation, warrantyExpirationDate,
                modelNumber, manufacturer, warehouseAddress, orderNumber, serialNumber);

        System.out.println("Drone successfully edited\n");
    }

    private static void deleteDrone() {
        System.out.println("Delete a drone");

        var serialNumber = Questionnaire.askString("Serial Number", null, (value) -> !value.isBlank());
        Database.update("DELETE FROM Drone WHERE SerialNumber = ?", serialNumber);
        System.out.println("Drone successfully deleted\n");
    }

    private static void listDrones() {
        var drones = Database.query(Drone.class, "SELECT * FROM Drone");
        Database.printRecordList(drones);
        System.out.println();
    }

    private static void searchDrones() {
        System.out.println("Search for a drone");
        var serialNumber = Questionnaire.askString("Serial Number", null, (value) -> !value.isBlank());
        var drones = Database.query(Drone.class, "SELECT * FROM Drone WHERE SerialNumber = ?", serialNumber);
        Database.printRecordList(drones);
        System.out.println();
    }

}
